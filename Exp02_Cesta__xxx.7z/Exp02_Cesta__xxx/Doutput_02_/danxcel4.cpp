
#include "danxincl.h"

// Global var
extern Exbd *exbd[NCORES];
#if(DEBUG0==YA)
float voxgrid[GRIDXX][GRIDYY][GRIDZZ];
#endif

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Loadgrid(int thid,char *file,int opt) {
char str[20];
int  vx,vy,vz,val,ii,si,sr; 
FILE *fp;
Exbd *edp=exbd[thid];

#if(NDIMS==2)
// opt=0: IS,opt=1: TG
strcpy(str,"File not found");
if((fp=fopen(file,"r"))==NULL) Leavexec(str);
if(0==0) {
   if(opt!=2) for(vx=-1;vx<GRIDXX;vx++) fscanf(fp,"%d",&val);
   for(vy= 0;vy<GRIDYY;vy++) {
      if(opt!=2) fscanf(fp,"%d",&val);
      for(vx=0;vx<GRIDXX;vx++) {
         fscanf(fp,"%d",&val);
         if(opt==0) edp->envr.etisooodp0grid[vx][GRIDYY-1-vy][0]=val;
         if(opt==1) edp->envr.cdisooodp0grid[vx][GRIDYY-1-vy][0]=val;
         if(opt==2) edp->envr.cdtgooodplgrid[vx][GRIDYY-1-vy][0]=val;
      }
   }
}
fclose(fp);
#endif

#if(NDIMS==3)
strcpy(str,"File not found");
if((fp=fopen(file,"r"))==NULL) Leavexec(str);
ii=0;
for(vz=0;vz<GRIDZZ;vz++) for(vy=0;vy<GRIDYY;vy++) for(vx=0;vx<GRIDXX;vx++) {
   if((ii==0)||((ii+0)%GRIDXX==0))
      sr=fscanf(fp,"\n (vz:%d vy:%d vx:%d)",&val,&val,&val);
   sr=fscanf(fp," %d",&val); ii++;
   if(opt==0) edp->envr.etisooodp0grid[vx][vy][vz]=val;
   if(opt==1) edp->envr.cdisooodp0grid[vx][vy][vz]=val;
   if(opt==2) edp->envr.cdtgooodplgrid[vx][vy][vz]=val;
}
fclose(fp);
#endif

#if(MNETON==YA)
if(opt==3) {
   if((fp=fopen(file2,"r"))==NULL) Leavexec("File not found");
   // Loads target inputs
   fscanf(fp," %d",&edp->envr.mtv.iopar[0][0].x);
   fscanf(fp," %d",&edp->envr.mtv.iopar[0][0].y);
   fscanf(fp," %d",&edp->envr.mtv.iopar[0][0].z);
   for(ii=0;ii<EXARSZ;ii++)
      for(si=0;si<SZSUSP;si++) 
         fscanf(fp," %f",&edp->envr.mtv.iotar[0][ii][si]);
   // Loads target outputs
   fscanf(fp," %d",&edp->envr.mtv.iopar[1][0].x);
   fscanf(fp," %d",&edp->envr.mtv.iopar[1][0].y);
   fscanf(fp," %d",&edp->envr.mtv.iopar[1][0].z);
   for(ii=0;ii<EXARSZ;ii++)
      for(si=0;si<SZSUSP;si++) 
         fscanf(fp," %f",&edp->envr.mtv.iotar[1][ii][si]);
   fclose(fp);
}
#endif

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Loadmemo(int thid) {
char buf[2000];
int  pi,gy,bi,ii,aiv,sr,gi,an,hi; 
FILE *fp; float afv;
Exbd *edp=exbd[thid];

// History
fp=fopen(HSTXFN,"r"); 
if(fp!=NULL) opened
   fgets(buf,2000,fp);
   //for(ii=0;ii<FITHST;ii++) opened
   an = (edp->cn)/HSTSTP;
   for(ii=an;ii>=0;ii--) opened      
      for(gy=0;gy<NNGUYS;gy++) opened 
         fscanf(fp," %d %d %f",&an,&an,&afv);
         for(hi=0;hi<LFSPAN;hi++) opened
            fscanf(fp,"%f",&afv);
            edp->shadhst[gy][ii][hi] = afv;
         closed
         fprintf(fp,"\n");
      closed
   closed
closed
if(fp!=NULL) fclose(fp);

// GENXFN
fp=fopen(GENXFN,"r"); if(fp!=NULL) {
   sr=fscanf(fp,"\nCYCLE %d\n",&edp->cn0);
   // for(ii=0;ii<2;ii++) fgets(buf,200,fp);
   for(pi=0;pi<NPOPS;pi++) {
      for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
         sr=fscanf(fp,"%d)",&aiv);
         sr=fscanf(fp,"%f", &afv); 
         edp->popa[pi]->guys[gy].shad=afv;
         sr=fscanf(fp,"%f", &afv); 
         edp->popa[pi]->guys[gy].gaft=afv;
         // metabolism operators
         for(bi=0;bi<(GNHSZ+OXARSQ);bi++) {
            if((bi-GNHSZ)%OXRXSQ==0)
               sr=fscanf(fp," \n(%d)",&aiv);
            sr=fscanf(fp,"%d",&aiv); 
            edp->popa[pi]->guys[gy].gen[bi]=aiv;
         }
         // developmental genes
         for(bi=(GNHSZ+OXARSQ);bi<GENXSZ;bi++) {
            if((bi-(GNHSZ+OXARSQ))%CGOXSQ==0)
               sr=fscanf(fp," \n[%d]",&aiv);
            sr=fscanf(fp,"%d",&aiv); 
            edp->popa[pi]->guys[gy].gen[bi]=aiv;
         }
      }
   }
}
if(fp!=NULL) fclose (fp);

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Savememo(int thid) {
char *tmpfilename,str[10];
int  gi,pi,gy,vx,vy,vz,cn,gq,an;
int  bi,hi,ce,ii,ivara,lht,fn;
float ar,br;
FILE *fp; Cgx *cgx;
Exbd *edp=exbd[thid];

// History
fp=fopen(HSTXFN,"w"); 
if(fp!=NULL) opened
   fprintf(fp,"%5s%5s%5s"," cn "," gi "," of ");
   for(hi=0;hi<LFSPAN;hi++) fprintf(fp," %4d",hi);
   fprintf(fp,"\n");
   //for(ii=0;ii<FITHST;ii++) opened
   an = (edp->cn)/HSTSTP;
   for(ii=an;ii>=0;ii--) opened      
      for(gy=0;gy<NNGUYS;gy++) opened 
         ar = -1; //edp->shadhst[gy][ii][hi];      
         fprintf(fp," %4d %4d %4.2f",ii,gy,ar);
         for(hi=0;hi<LFSPAN;hi++) opened
            ar = edp->shadhst[gy][ii][hi];
            fprintf(fp,"% 4.2f",ar);
         closed
         fprintf(fp,"\n");
      closed
   closed
closed
if(fp!=NULL) fclose(fp);

// FILE
lht = strlen(OUTDIRN)+50;
tmpfilename = (char *)malloc(lht);
strcpy(tmpfilename,OUTDIRN);
strcat(tmpfilename,"\\bxgen_");
//itoa (edp->cn,str,10);
snprintf(str,10,"%d",edp->cn);
if(edp->cn%10000 == 0) {
   strcat(tmpfilename,str); 
   strcat(tmpfilename,".txt"); 
   fp=fopen(tmpfilename,"w"); 
}
else fp=fopen(GENXFN,"w");
if(fp!=NULL) {
   fprintf(fp,"\nCYCLE %6d\n",edp->cn);
   for(pi=0;pi<NPOPS;pi++) {
      for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
         fprintf(fp,"%4d) %9.6f %9.6f ",gy,
            edp->popa[pi]->guys[gy].shad,
            edp->popa[pi]->guys[gy].gaft);
         // metabolism operators
         for(bi=0;bi<(GNHSZ+OXARSQ);bi++) {
            if((bi-GNHSZ)%OXRXSQ==0)
               fprintf(fp," \n(%3d)",(bi-GNHSZ)/OXRXSQ);
            fprintf(fp," %4d",(int)edp->popa[pi]->guys[gy].gen[bi]);
         }
         // change instructions
         for(bi=(GNHSZ+OXARSQ);bi<GENXSZ;bi++) {
            if((bi-(GNHSZ+OXARSQ))%CGOXSQ==0)
               fprintf(fp," \n[%3d]",(bi-(GNHSZ+OXARSQ))/CGOXSQ);
            fprintf(fp," %4d",(int)edp->popa[pi]->guys[gy].gen[bi]);
         }
         fprintf(fp," \n");
      }
   }
}
if(fp!=NULL) fclose(fp);
free(tmpfilename);

fp=fopen(CGARFN,"w"); 
fprintf(fp,"%6s","nr) ;");
fprintf(fp,"%6s%6s%6s%6s","arpos;","exord;","act;","tmr;");
for(hi=0;hi<10;hi++) fprintf(fp,"hi couple|");
fprintf(fp,"%6s%6s%6s","ms0 ;","ms1 ;","conr ;");
//for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
for(pi=0;pi<1;pi++) for(gy=0;gy<1;gy++) {
   gi=pi*POPXSZ+gy;
   fprintf(fp,"\n%4d _%4d _",pi,gy);
   edp->popa[pi]->Gendecoder(0,edp->popa[pi]->guys[gy].gen,NULL,1);
   for(ce=0;ce<edp->cgarsz;ce++)
      edp->par[ce]=(float)edp->cgar[ce].arpos/edp->cgarsz;
   Mysortxcgx(0,edp->par,edp->cgarsz,1,edp->cgar,edp->cgar);
   for(ce=0;ce<edp->cgarsz;ce++) {
      fprintf(fp,"\n%4d);",ce);
      cgx=&edp->cgar[ce]; 
      fprintf(fp," %4d;",cgx->arpos);
      fprintf(fp," %4d;",cgx->exord);
      fprintf(fp," %4d;",cgx->on);
      fprintf(fp," %4d;",cgx->as);
      ivara = 0;
      for(hi=0;hi<LFSPAN;hi++) {
         if(cgx->mos[hi]!=0) if(ivara<10) {
            fprintf(fp,"%3d %5d|",hi,cgx->mos[hi]);
            ivara++;
         }
      }
      for(hi=ivara;hi<10;hi++) fprintf(fp,"%10s","_ |");
      fprintf(fp,"%5d;",cgx->cgo.ms0);
      fprintf(fp,"%5d;",cgx->cgo.ms1);
      fprintf(fp,"%5d;",cgx->cgo.conr);
   }
}
fclose(fp);

fp=fopen(DHLSFN,"w");
fprintf(fp,"%6s","nr) _");
fprintf(fp,"%6s%6s%6s","xx _","xx _","as _");
for(hi=0;hi<LFSPAN;hi++) fprintf(fp," hi%2d_",hi);
fprintf(fp,"%6s%6s%6s","arpos_","exord_","as _");
//for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
for(pi=0;pi<1;pi++) for(gy=0;gy<1;gy++) {
   gi=pi*POPXSZ+gy;
   fprintf(fp,"\n%4d _%4d _",pi,gy);
   edp->dhnro = edp->dhnrf; 
   edp->dharo = edp->dharf;
   edp->dhnro=edp->dhnral[gi]; 
   edp->dharo=edp->dharal[gi];
   ivara=edp->dhnro;
   for(ce=0;ce<=ivara;ce++) {
      fprintf(fp,"\n");
      fprintf(fp,"%4d)_",ce);
      fprintf(fp,"  xx _  xx _");
      fprintf(fp," %4d_",edp->dharo[ce].asval);
      for(hi=0;hi<LFSPAN;hi++) opened
         fprintf(fp," %4d_",edp->dharo[ce].moc[hi]);
      closed
      // cgx
      cgx=&edp->dharo[ce].cgx;
      fprintf(fp," %4d_",cgx->arpos);
      fprintf(fp," %4d_",cgx->exord);
      fprintf(fp," %4d_",cgx->on);
   }
}
fclose(fp);

#if(NDIMS==3)
lht = strlen(VTKFILE)+14;
tmpfilename = (char *)malloc(lht);

for(hi=edp->frz[edp->gq].ls;hi<=edp->frz[edp->gq].us;hi++) {
//for(hi=0;hi<=27;hi++) {
//for(hi=0;hi<=0;hi++) {
   sprintf(str,"%d",hi);
   strcpy(tmpfilename,VTKFILE);
   if (hi<10) strcat(tmpfilename, "0");
   strcat(tmpfilename, str);
   strcat(tmpfilename, "_9999");
   strcat(tmpfilename, ".vtk");
   Savevtk(thid,hi,tmpfilename);
}
free(tmpfilename);
#endif

#if(MNETON==YA)
// code removed
#endif

}

#define SPEC_SHAPE0 0
#define SPEC_SHAPE1 0
//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Savevtk(int thid, int hi, char *filename) {
int   vx,vy,vz,sy,ncls,npts,ptnr,ii,jj,aiv,biv;
float xx,yy,zz,col;
FILE  *fp;
Exbd *edp=exbd[thid];

#if(DEBUG7==1)
char  cvar=0;
int   nhs,sx,sz,civ,cells,holes;
float avgcol,cfv;

FORVXYZ voxgrid[vx][vy][vz]=
   (float)edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0;
FORVXYZ {
   if(edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0!=-1)
      cvar=cvar;
   nhs=6; for(ii=0;ii<17;ii++) avgcol=0; cells=0; holes=0;
   for(sx=vx-nhs;sx<=vx+nhs;sx++)
   for(sy=vy-nhs;sy<=vy+nhs;sy++)
   for(sz=vz-nhs;sz<=vz+nhs;sz++) {
      if((sx>=0)&&(sx<GRIDXX)&&(sy>=0)&&(sy<GRIDYY)&&(sz>=0)&&(sz<GRIDZZ)) {
         civ=edp->envr.ooacooodpagrid[hi][sx][sy][sz].e0;
         if(civ!=-1) cells++; else holes++;
         if(civ!=-1) avgcol+=civ;
      }
   }
   if(cells>0) avgcol/=cells;

   // assigns
   voxgrid[vx][vy][vz]=-1;
   if(cells>0) voxgrid[vx][vy][vz]=avgcol;
   if((float)holes*0.80>(float)cells) voxgrid[vx][vy][vz]=-1;
}
FORVXYZ {
   if(voxgrid[vx][vy][vz]==-1) {
      edp->envr.ooacooodpagrid[hi][vx][vy][vz].d0=-1;
      edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0=-1;
   }
}
#endif

xx=0; yy=0; zz=0; col=0; // to avoid warnings

#if(ZSTEPS==YA)
// code removed
#endif
fp=fopen(filename,"w");

// Header
fprintf(fp,"# vtk DataFile Version 3.0\n");
fprintf(fp,"vtk output\n");
fprintf(fp,"ASCII\n");
fprintf(fp,"DATASET UNSTRUCTURED_GRID\n");
fprintf(fp,"\n");

// POINTS
fprintf(fp,"POINTS");
ncls=0;
FORVXYZ {
   aiv=edp->envr.ooacooodpagrid[hi][vx][vy][vz].d0;
   biv=edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0;
   if((aiv!=-1)&&(biv!=-1)) ncls++;
}
npts=ncls*8;
fprintf(fp," %5d",npts);
fprintf(fp," float\n\n");
vz=0;
FORVXYZ {
   #if(DEBUG0==YA)
   vz=vz+0;
   #endif
   aiv=edp->envr.ooacooodpagrid[hi][vx][vy][vz].d0;
   biv=edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0;
   //aiv=edp->envr.cdtgooodplgrid  [vx][vy][vz];
   sy=vy;
   #if(SPEC_SHAPE0==1)
   sy=vy;
   #endif
   #if(SPEC_SHAPE1==1)
   sy=2*GRIDYY-vy-1;
   #endif
   if((aiv!=-1)&&(biv!=-1)) {
      for(jj=0;jj<8;jj++) {
         if(jj==0) { xx=(float)(vx+0)/100; yy=(float)(sy+0)/100; zz=(float)(vz+0)/100; }
         if(jj==1) { xx=(float)(vx+1)/100; yy=(float)(sy+0)/100; zz=(float)(vz+0)/100; }
         if(jj==2) { xx=(float)(vx+0)/100; yy=(float)(sy+1)/100; zz=(float)(vz+0)/100; }
         if(jj==3) { xx=(float)(vx+1)/100; yy=(float)(sy+1)/100; zz=(float)(vz+0)/100; }
         if(jj==4) { xx=(float)(vx+0)/100; yy=(float)(sy+0)/100; zz=(float)(vz+1)/100; }
         if(jj==5) { xx=(float)(vx+1)/100; yy=(float)(sy+0)/100; zz=(float)(vz+1)/100; }
         if(jj==6) { xx=(float)(vx+0)/100; yy=(float)(sy+1)/100; zz=(float)(vz+1)/100; }
         if(jj==7) { xx=(float)(vx+1)/100; yy=(float)(sy+1)/100; zz=(float)(vz+1)/100; }
         fprintf(fp,"%.2f %.2f %.2f  ",xx,yy,zz);
      }
      fprintf(fp,"\n");
   }
}

// Cells
ptnr=0;
fprintf(fp,"\ncells %d %d",ncls,ncls*9);
while(ptnr<ncls*8) {
   fprintf(fp,"\n8");
   for(jj=0;jj<8;jj++) fprintf(fp," %5d",ptnr++);
}

// Cell types
fprintf(fp,"\n\nCELL_TYPES %d\n",ncls);
for(ii=0;ii<ncls;ii++) {
   fprintf(fp,"11 ");
   if((ii+1)%20==0) fprintf(fp,"\n");
}

// Cell data
fprintf(fp,"\n\nCELL_DATA %d",ncls);
fprintf(fp,"\n\nSCALARS scalars float");

// Lookup table
fprintf(fp,"\n\nLOOKUP_TABLE default\n");
FORVXYZ {
   aiv=edp->envr.ooacooodpagrid[hi][vx][vy][vz].d0;
   biv=edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0;
   if((aiv!=-1)&&(biv!=-1)) {
      #if(DEBUG7==1)
      cfv=voxgrid[vx][vy][vz];
      #endif
      //color map
      #if(VTKOPT==0)
      if(aiv!=  -1 ) col=(float)0.25;
      if(aiv>=30000) col=(float)0.50;
      if(aiv>=60000) col=(float)0.75;
      if(aiv==  -2 ) col=(float)1.00;
      if(aiv!=  -1 ) fprintf(fp,"%4.2f\n",col);
      #endif
      #if(VTKOPT==1)
      if(aiv!=-1) {
         col=(float)biv/15;
         #if(DEBUG7==1)
         col=cfv/15;
         #endif
         fprintf(fp,"%4.2f\n",col); }
      #endif
   }
}
if(fp!=NULL) fclose(fp);

}

#define SPEC_SHAPE0 0
#define SPEC_SHAPE1 0
//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Savegrd(int thid, int hi, char *filename) {
#if(ZSTEPS==YA)
// code removed
#endif
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Prexline(int thid) {
char cvar = 0;
int gy,ci,hi,ii; 
int neusection;
int cgarszold,dnaszold;
int at,bi,bo,bx,bj,*gen;
int dnpiecea[ASXXSQ]; 
int begstep;
Exbd *edp=exbd[thid];

// gq change determination
neusection = 0;
for(ii=0;ii<NAMS;ii++)
   if(edp->cn%edp->frz[ii].ge==0) 
      neusection = 1;
if(edp->gq==0) cgarszold = 0;
else cgarszold = edp->frz[edp->gq-1].xe;
dnaszold = (GNHSZ+OXARSQ+(CGOXSQ*cgarszold));
   
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
if(neusection==0) goto PREXBLUE; 
// refresh randomness of new section
for(gy=1;gy<POPXSZ;gy++) {
   for(bi=dnaszold;bi<GENXSZ;bi++) {
      edp->popa[0]->guys[gy].gen[bi] = Rnd1(4);
   }
}
PREXBLUE:cvar=cvar; 
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

float ubord = pow(4,(float)OPXXSQ);
//if(neusection==0) goto PREXCYAN;
if(edp->cn%1000!=0) goto PREXCYAN;
//cgarszold = edp->frz[edp->gq-1].xe;
//cgarszold = edp->cgarsz-100; 
cgarszold = (int)(edp->cgarsz*0.0f); 
if(cgarszold<=0) cgarszold=0; 
begstep = edp->frz[edp->gq].fs+GRACEP;
for(gy=0;gy<edp->popa[0]->popsz;gy++) {
   gen = &edp->popa[0]->guys[gy].gen[0];
   edp->popa[0]->Gendecoder(0,edp->popa[0]->guys[gy].gen,NULL,1);
   for(ci=cgarszold;ci<edp->cgarsz;ci++) {
      hi = ci%LFSPAN; // target value 
      // check notused 
      int notused = 1;      
      for(int ce=0;ce<=edp->dhnral[gy];ce++) 
         if(ci==edp->dharal[gy][ce].cgx.arpos) 
            notused = 0;        
      // check notused_end 
      if(hi>=begstep) 
      //if(edp->cgar[ci].exord/ubord<=0.5) 
      if(Rnd1(1000)<=800)
      if(notused == 1) {
         edp->cgar[ci].as = hi;
         bo = GNHSZ+OXARSQ+(edp->cgar[ci].arpos*CGOXSQ); //bi=bx+bj
         Varrescale(&edp->cgar[ci].as,LFSPAN,Intpower(4,ASXXSQ));
         Cvint2base(&dnpiecea[0],&edp->cgar[ci].as,ASXXSQ,4,&bj); 
         for(bi=0;bi<ASXXSQ;bi++)
            gen[bo+1+OPXXSQ+bi] = dnpiecea[bi];
      }
   }
}
PREXCYAN:cvar=cvar;

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void  Body::Germline(int thid) {
char  cvar=0;
Cgx   curcgx;
int   gi,gy,ii,ci,hi,n0,nr;
int   pres,sva,svb,rnok,cnt,aiv,biv;
Exbd *edp=exbd[thid];

for(gy=0;gy<edp->popa[0]->popsz;gy++) {
   gi=0*POPXSZ+gy;
   aiv=edp->dhnral[gi]; 
   if (aiv==1) aiv=0; // ACHTUNG: ad-hoc!!!
   if(gi==0) goto GTLAAA;
   edp->popa[0]->Gendecoder(0,edp->popa[0]->guys[gy].gen,NULL,1);
   #if(DEBUG0==YA)
   //gi=0;
   #endif
   for(ci=0;ci<edp->cgarsz;ci++) {
      nr = 0; // counter
      memcpy(&curcgx,&edp->cgar[ci],sizeof(Cgx));
      // checks whether curcgx.mos matches any moc in moc array
      pres=NO;
      for(ii=0;ii<=aiv;ii++) {
         //as=curcgx.as;
         biv=Mocmatch(&curcgx.mos[0],
            &edp->dharal[gi][ii].moc[0],curcgx.as);
         if (biv==YA) { pres=YA; break; }
      }
      if((pres==NO)&&(nr<=nr)) {
         // selects randomly existing epigenetic type
         rnok=NO; 
         cnt = 0; // counter
         do {
            n0=Rnd1(aiv+1);
            if(n0>aiv) n0=aiv; 
            cnt++;
            if(edp->dharal[gi][n0].moc[0]!=-1) rnok=YA;
         }  while((rnok==NO)&&(cnt<10));
         for(hi=0;hi<LFSPAN;hi++) 
            curcgx.mos[hi]=edp->dharal[gi][n0].moc[hi];
         Genchger(gy,&edp->popa[0]->guys[gy].gen[0],&curcgx);
         nr++;
      }
   }
   GTLAAA:cvar=cvar;
}

#if(DEBUG7==YA)
Gpstatsx(this);
#endif

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Genchger(int gy,int gen[],Cgx *curcgx) {
int bo,bx,bj,hi,dnpiecea[(CETXSQ*LFSPAN)];
//int dnpieceb[(DPLSQ-1)],aa[4],by,ii; Cd dpl[2];

// introduce sanity checks ACHTUNG !!
bo=GNHSZ+OXARSQ+(curcgx->arpos*CGOXSQ); //bi=bx+bj
// dnpiece
for(bj=0;bj<(CETXSQ*LFSPAN);bj++) { dnpiecea[bj]=-1; } bj=0;
for(hi=0;hi<LFSPAN;hi++) { //ACHTUNG Varrescale
   Cvint2base(&dnpiecea[bj],&curcgx->mos[hi],CETXSQ,4,&bj); }
// dv  input, sets activation to off
bx=0;
if(gy==0)
   gen[bo+bx]=0;
// dv  input, sets mos
bx=(1+OPXXSQ+ASXXSQ+1);
for(bj=0;bj<(CETXSQ*LFSPAN);bj++) gen[bo+bx+bj]=dnpiecea[bj];
// dv  input, sets masking bits to active
bx=(1+OPXXSQ+ASXXSQ+1)+(CETXSQ*LFSPAN);
for(bj=0;bj<LFSPAN;bj++) gen[bo+bx+bj]=3;

}

//!------------------------------------------------------------------
//! FCT
//!------------------------------------------------------------------
void Body::Clsrinit(Clsr *cs,int _clcnd) {
Lwriter(Lxxx,cs,-1,-1,_clcnd,-1); cs->dhnrc3=65535;
}

//!------------------------------------------------------------------
//! FCT
//!------------------------------------------------------------------
void Body::Moveclsr(int thid,Clsr *csd,Clsr *css) {
Exbd *edp=exbd[thid];
memcpy(csd,css,sizeof(Clsr));
memcpy(css,&edp->cst,sizeof(Clsr));
#if(MNETON==YA)
csd->mclvar=css->mclvar;
css->mclvar=edp->cst.mclvar;
#endif
}

//!------------------------------------------------------------------
//! FCT
//!------------------------------------------------------------------
void Body::Copyclsr(Clsr *csd,Clsr *css) {
memcpy(csd,css,sizeof(Clsr));
#if(MNETON==YA)
csd->mclvar=css->mclvar;
#endif
}

//!------------------------------------------------------------------
//! FCT
//!------------------------------------------------------------------
Cell::Cell(Body * bdp,int *_etc,int _clcnd) {
clbdp=bdp; Cellinit(_etc,_clcnd);
}

//!------------------------------------------------------------------
//! FCT
//!------------------------------------------------------------------
void Cell::Cellinit(int *_etc,int _clcnd) {
clcnd=_clcnd; dhnrc=-1; conr=-1; drv=YA;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Mnetcalc(int thid,int gi) {
#if(MNETON==YA)
// code removed
#endif
}

