
#include "danxincl.h"

// Global var
extern Exbd  *exbd[NCORES];
extern Cvare *cve_[NCORES];

// Module var
int popsz0,popsz1;
Guy guys0[POPXSZ],guys1[POPXSZ],guysold[POPXSZ];

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Pop::Genrnd(int thid,int nn) {
int gy,bi;

for(gy=0;gy<popsz;gy++) 
   Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=nn;
gy=0;
while(gy<nn) {
   for(bi=0;bi<dnasz;bi++)
      if(dnp[bi].flag==1) 
         guys1[gy].gen[bi]=Rnd1(dnp[bi].bval);
      else guys1[gy].gen[bi]=dnp[bi].bval;
   if(Genvalid(thid,guys1[gy].gen,NULL)==YA) gy++;
   else Gencpy(guys1[gy].gen,NULL,0,dnasz);
}
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Pop::Reproduction(int thid,int sons) {
int gy,ii,rn0,son=0; 
float gaftsum,rn,*wheel;

// cmt: gaft must be >=0
wheel=(float *)malloc(sizeof(float)*popsz);
for(gy=0;gy<popsz;gy++) 
   Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=sons;

gaftsum=0; 
for(gy=0;gy<popsz0;gy++) gaftsum+=guys0[gy].gaft;
if(gaftsum>0) {
   wheel[0]=guys0[0].gaft / gaftsum;
   for(gy=0;gy<popsz0-1;gy++) 
      wheel[gy+1] = wheel[gy]+guys0[gy+1].gaft/gaftsum;
   for(ii=0;ii<sons;ii++) {
      rn=Rnd1(1000)/(float)1000;
      if(rn < wheel[0]) son=0;
      for(gy=0;gy<popsz0-1;gy++) 
         if(rn>=wheel[gy] && rn<wheel[gy+1]) {
            son=gy+1; break; }
      Gencpy(guys1[ii].gen,guys0[son].gen,0,dnasz);
   }
}
else
   for(ii=0;ii<sons;ii++) {
      rn0=Rnd1(popsz0);
      Gycp(1,guys1,guys0,ii,rn0,1);
   }

free(wheel);
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Pop::Decimation(int thid,int ndeads,unsigned char deathtype) {
int gy,*ord; float *par;

ord=(int*)malloc(sizeof(int)*popsz); 
par=(float*)malloc(sizeof(float)*popsz);
for(gy=0;gy<popsz;gy++) ord[gy]=0;
for(gy=0;gy<popsz;gy++) par[gy]=0;

for(gy=0;gy<POPXSZ;gy++) 
   Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=popsz0-ndeads;

for(gy=0;gy<popsz0;gy++) par[gy]=guys0[gy].gaft;
Mysortxxxx(&par[0],popsz0,0,&ord[0]);
for(gy=0;gy<popsz0-ndeads;gy++) {
   if(deathtype==0) Gycp(1,guys1,guys0,gy,ord[gy],1);
   if(deathtype==1) Gycp(1,guys1,guys0,gy,ord[popsz0-1-gy],1);
}

free(ord); free(par);
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Pop::Crossover(int thid,float pcross) {
uchar crossok=NO;
int   *crossar,*crossdna0,*crossdna1;
int   gy,ii,n,rn0,rn1,rn4,rn5,aiv,biv,vers;
float rn3;

crossdna0=(int *)malloc(sizeof(int)*dnasz);
crossdna1=(int *)malloc(sizeof(int)*dnasz);
crossar  =(int *)malloc(sizeof(int)*popsz);

for(gy=0;gy<popsz;gy++) 
   Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=popsz0;
for(gy=0;gy<popsz0;gy++) crossar[gy]=gy;

for(n=popsz0;n>0;n-=2) {
   ii=popsz0-n;
   rn0=-1; rn1=-1; 
   while(rn0>=rn1) { rn0=Rnd1(n); rn1=Rnd1(n); }
   rn3=Rnd1(1000)/(float)1000;
   // Crossover attempt
   if(rn3<pcross) {
      crossok=NO; vers=0;
      while((crossok==NO) && (vers<=ATPMAX)) {
         rn4=Rnd1(dnasz-0); // 1. crossover point
         rn5=Rnd1(dnasz-0); // 2. crossover point
         if (rn4<=rn5) { aiv=rn4; biv=rn5; }
         if (rn4> rn5) { aiv=rn5; biv=rn4; }
         Gencpy(crossdna0,guys0[crossar[rn0]].gen,0,dnasz);
         Gencpy(crossdna1,guys0[crossar[rn1]].gen,0,dnasz);
         Gencpy(crossdna0,guys0[crossar[rn1]].gen,aiv,biv-aiv+1);
         Gencpy(crossdna1,guys0[crossar[rn0]].gen,aiv,biv-aiv+1);
         if(Genvalid(thid,&crossdna0[0],NULL)==NO) goto CROSBLUE;
         if(Genvalid(thid,&crossdna1[0],NULL)==NO) goto CROSBLUE;
         Gencpy(guys1[ii  ].gen,crossdna0,0,dnasz);
         Gencpy(guys1[ii+1].gen,crossdna1,0,dnasz);
         crossok=YA;
         CROSBLUE:vers++;
      }
   }
   // Crossover failure
   if((rn3>=pcross) || (crossok==NO)) {
      Gycp(1,guys1,guys0,ii+0,crossar[rn0],1);
      Gycp(1,guys1,guys0,ii+1,crossar[rn1],1);
   }
   // Crossar rearrengement
   for(gy=rn0;  gy<=n-1;gy++) crossar[gy]=crossar[gy+1];
   for(gy=rn1-1;gy<=n-1;gy++) crossar[gy]=crossar[gy+1];
}

free(crossdna0);
free(crossdna1);
free(crossar);
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Pop::Mutation(int thid) {
uchar dnaok;
int   *neudna,gy,ii,vers,mxchgd;
int   gn,rna,rnb,tmr,bn,bi; 
float pmut,ar,br;
Exbd *edp=exbd[thid];

neudna=(int *)malloc(sizeof(int)*dnasz);
mxchgd=(int  )(MPCMUT*dnasz);

for(gy=0;gy<popsz;gy++) 
   Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=popsz0;

for(gy=0;gy<popsz0;gy++) {
   //ar=0;
   ar = Rnd1(1000)/(float)1000;
   dnaok=NO; vers=0;
   if(ar<PMUTAT) {
      // decodes guy (need for cgar)
      while((dnaok==NO) && (vers<=ATPMAX)) {
         Gendecoder(thid,guys0[gy].gen,NULL,0);
         Gencpy (neudna, guys0[gy].gen,0,dnasz);
         rna = Rnd1(mxchgd);         
         bn = GNHSZ+OXARSQ;
         // solution A
         for(ii=1;ii<=rna;ii++) {
            bi=Rnd1(dnasz);            
            br = Rnd1(1000)/(float)1000;
            gn = (bi-bn)/CGOXSQ;            
            tmr = edp->cgar[gn].as;
            pmut = edp->pmutar[tmr];
            if(dnp[bi].flag==1) if(br<=pmut) { 
               rnb = Rnd1(dnp[bi].bval); 
               neudna[bi] = rnb; 
            }
         }         
         // solution B
         /*for(bi=1;bi<dnasz;bi++) {
            br = Rnd1(1000)/(float)1000;
            gn = (bi-bn)/CGOXSQ;            
            tmr = edp->cgar[gn].as;
            pmut = edp->pmutar[tmr]*MPCMUT;
            if(dnp[bi].flag==1) if(br<=pmut) { 
               rnb = Rnd1(dnp[ii].bval); 
               neudna[bi] = rnb; 
            }
         }*/        
         if(Genvalid(thid,&neudna[0],NULL)==YA) {
            Gencpy(guys1[gy].gen,neudna,0,dnasz);
            dnaok=YA;
         }
         else vers++;
      }
   }
   if((ar>=PMUTAT) || (dnaok==NO)) {
      Gencpy(guys1[gy].gen,guys0[gy].gen,0,dnasz); 
   }
}

free(neudna);
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Pop::Gycp (int opt,Guy gard[],Guy gars[],int ad,int as,int n) {

for(int gy=0;gy<n;gy++) {
   Gencpy(gard[ad+gy].gen,gars[as+gy].gen,0,dnasz);
   if(opt==1) gard[ad+gy].gaft=gars[as+gy].gaft;
}
if(gard==guys0) popsz0=n;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Pop::Galoop(int thid,int opt) {
int  gy;
Exbd *edp=exbd[thid];

// Inits guys0,guys1,guysold
for(gy=0;gy<popsz;gy++) memcpy(&guys0  [gy],&edp->guyt,sizeof(Guy));
for(gy=0;gy<popsz;gy++) memcpy(&guys1  [gy],&edp->guyt,sizeof(Guy));
for(gy=0;gy<popsz;gy++) memcpy(&guysold[gy],&guys[gy], sizeof(Guy));
for(gy=0;gy<popsz;gy++) memcpy(&guys   [gy],&edp->guyt,sizeof(Guy));

// nkids0 gen's are sons of spopsz0
Gycp(1,guys0,guysold,0,0,spopsz0);
Reproduction(thid,nkids0);
Gycp(0,guys0,guys1,0,0,nkids0);
Crossover(thid,PCROSS);
Gycp(0,guys0,guys1,0,0,nkids0);
Mutation(thid);
Gycp(0,guys ,guys1,0,0,nkids0);

// Replaces worst nkids0+nkids1 of spopsz0
Gycp(1,guys0,guysold,0,0,spopsz0);
Decimation(thid,nkids0+nkids1,0);
Gycp(0,guys ,guys1,nkids0+nkids1,0,spopsz0-nkids0-nkids1);

// Old chmp in pos 0
memcpy(&guys[0],&guysold[0],sizeof(Guy));
// Init guys - Checks validity
for(gy=0;gy<popsz;gy++) {
   if(Genvalid(thid,guys[gy].gen,&guys[gy])==NO) {
      Genrnd(thid,1); Gencpy(guys[gy].gen,guys1[0].gen,0,dnasz); }
   guys[gy].neugy=YA;
   //guys[gy]. gaft= 0;
   /*for(gyold=0;gyold<popsz;gyold++) {
      if(memcmp(&guys[gy].gen[0],&guysold[gyold].gen[0],dnasz*sizeof(int))==0) {
         memcpy(&guys[gy],&guysold[gyold],sizeof(Guy));
         guys[gy].neugy=NO;
         break;
      }
   }*/
}

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
Pop::Pop (int thid,Body * bdp) {
Cons(thid,bdp);
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Pop::Cons(int thid,Body * _popbdp) {
int  gy,bi,ivara;

popbdp=_popbdp; popsz=POPXSZ; 
dnasz = GENXSZ;
spopsz0=POPSZ0; nkids0=NKIDS0; 
spopsz1=POPSZ1; nkids1=NKIDS1;

// Init dnp 
for(bi=0;bi<GENXSZ;bi++) {
   ivara=4;
   if(bi==0) ivara=CGARSZ; 
   if(bi==1) ivara=-1; 
   if(bi==2) ivara=DPLMAX;
   dnp[bi].bval=ivara; dnp[bi].flag=1; 
}

if(thid==0) {
   Genrnd(thid,popsz);
   for(gy=0;gy<popsz;gy++) {
      Gencpy(guys[gy].gen,guys1[gy].gen,0,dnasz);
      guys[gy].neugy = YA; 
      guys[gy].gaft = 0; guys[gy].shad = 0;
   }
   //Gendecoder(&guys[0].gen[0],&guys[0]);
}
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void  Pop::Gendecoder(int thid,int gen[],Guy *gyp,int opt) {
char  cvar=0;
int   ii,hi,ci,bi,si,dx,dy,dz;
int   ivara,ivarb,ivarc,ox,max,min,xf;
float coe;
Cgx   curcgx; Oxr curoxr;
Exbd *edp=exbd[thid];

// Decodes exp genome
for(ox=0;ox<edp->oxarsz;ox++) {
   // inits curoxr
   memset(&curoxr,0,sizeof(Oxr));
   bi=GNHSZ+ox*OXRXSQ;
   curoxr.oxarpos=ox;                      // act currently unused!
   if(gen[bi++]<=1) curoxr.act=0; else curoxr.act=1; curoxr.act=-1;
   Cvbase2int (&gen[bi],&curoxr.lrxx     ,LRXXSQ,4,&bi);
   for(ii=0;ii<MAXIPS;ii++)
   Cvbase2int (&gen[bi],&curoxr.isui[ii] ,SIXXSQ,4,&bi);
   for(ii=0;ii<MAXIPS+1;ii++)
   Cvbase2flt (&gen[bi],&curoxr.whts[ii] ,WHTXSQ,4,&bi);
   Cvbase2int (&gen[bi],&curoxr.osui     ,SIXXSQ,4,&bi);
   // varrescales
   for(ii=0;ii<MAXIPS;ii++)
   Varrescale (&curoxr.isui[ii],(int)Intpower(4,SIXXSQ),SZSUSP);
   Varrescale (&curoxr.osui    ,(int)Intpower(4,SIXXSQ),SZSUSP);
   // xxxx
   memcpy(&edp->oxar[ox],&curoxr,sizeof(Oxr));
}

// Inits cgar
if (opt==0) xf=0; if (opt==1) xf=edp->cgarxf;
for(ci=0;ci<xf;ci++)
   memcpy(&edp->cgar[ci],&edp->cgarf[ci],sizeof(Cgx));
for(ci=xf;ci<edp->cgarsz;ci++)
   memcpy(&edp->cgar[ci],&edp->cgxt,sizeof(Cgx));

for(ci=xf;ci<edp->cgarsz;ci++) {
   //inits curcgx
   memcpy(&curcgx,&exbd[thid]->cgxt,sizeof(Cgx));
   bi=GNHSZ+OXARSQ+ci*CGOXSQ;
   if(gen[bi++]<=1) curcgx.on=0; else curcgx.on=1;
   Cvbase2int(&gen[bi],&curcgx.exord,OPXXSQ,4,&bi);
   #if(MSFREEZE==NO)
   Varrescale(&curcgx.exord,(int)pow(4,(float)OPXXSQ),edp->cgarsz);
   #endif
   // input:dp
   Cvbase2int(&gen[bi],&curcgx.as,ASXXSQ,4,&bi);
   Varrescale(&curcgx.as,(int)Intpower(4,ASXXSQ),LFSPAN-1);
   Cvbase2int(&gen[bi],&ivarb,1,4,&bi);
   ivarb=3; // FORCE dp relevant
   if(ivarb<=1) curcgx.as=-1; // as not relevant
   if(ASON==NO) curcgx.as=-1;
   if(ASON==NO) gen[bi-1]=0; // on-the-fly correction
   //  input:etx
   for(hi=0;hi<LFSPAN;hi++) {
      Cvbase2int(&gen[bi],&curcgx.mos[hi],CETXSQ,4,&bi); }
   for(hi=0;hi<LFSPAN;hi++) {
      Cvbase2int(&gen[bi],&ivarb,1,4,&bi);
      // if(ivarb<=1) curcgx.etx[hi]=-1; // Force: all relevant
   }  // etx[hi] not relevant
   // output:dpl
   for(ii=0;ii<6;ii++) {
      //FORCE (pt 0 in NWB, 1 in SEF)
      if((ii==0)||(ii==2)||(ii==4)) gen[bi]=0; 
      if((ii==1)||(ii==3)||(ii==5)) gen[bi]=2; 
      if(gen[bi++]<=1) ivara=-1; else ivara=+1;
      Cvbase2int(&gen[bi],&ivarb,DPLXSQ-1,4,&bi);
      // dpl rescale or threshold
      //Varrescale(&ivara,(int)pow(4,DPLSQ-1),DPLMAX);
      //if(ivara>DPLMAX) ivara=DPLMAX;
      ivarc=edp->frz[edp->xqar[ci]].dl;
      if(ivarb>ivarc) ivarb=ivarc;
      ivara*=ivarb;
      // allows for external proliferation
      if((ii==0)||(ii==2)||(ii==4)) ivara+=1; // maxval=0 -> maxval=+1
      if((ii==1)||(ii==3)||(ii==5)) ivara-=1; // minval=0 -> minval=-1
      // dpl assignment
      if(ii==0) curcgx.cgo.dpl[0].x=ivara;
      if(ii==1) curcgx.cgo.dpl[0].y=ivara;
      if(ii==2) curcgx.cgo.dpl[0].z=ivara;
      if(ii==3) curcgx.cgo.dpl[1].x=ivara;
      if(ii==4) curcgx.cgo.dpl[1].y=ivara;
      if(ii==5) curcgx.cgo.dpl[1].z=ivara;
   }
   #if(NDIMS==2)
   curcgx.cgo.dpl[0].zz=0; curcgx.cgo.dpl[1].zz=0;
   #endif
   // output:ms0,ms1,shp,dgd
   Cvbase2int(&gen[bi],&curcgx.cgo.ms1   ,MS0XSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.ms0   ,MS1XSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.dgd[0],DGDXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.dgd[1],DGDXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.dgd[2],DGDXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.dgd[3],DGDXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.dgd[4],DGDXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.dgd[5],DGDXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.dgd[6],DGDXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.dgd[7],DGDXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.dgd[8],DGDXSQ,4,&bi);
   #if(NDIMS==2)
   for(ii=4;ii<8;ii++) curcgx.cgo.dgd[ii]=0;
   #endif
   // output:colours
   Cvbase2int(&gen[bi],&curcgx.cgo.conr,COLXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.c2nr,COLXSQ,4,&bi);
   // output:mnet-related
   for(ii=0;ii<2;ii++) for(si=0;si<SZSUSP;si++)
      Cvbase2int(&gen[bi],&curcgx.cgo.iosmsk[ii][si],SUFXSQ,4,&bi);
   for(ii=0;ii<OXRCHD;ii++)
      Cvbase2int(&gen[bi],&curcgx.cgo.oxrchd[ii],XCHXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curcgx.cgo.olrxxx,OLRXSQ,4,&bi);

   // on-the-fly corrections and forced -----------------------------
   //if(curcgx.cgo.ms0==0) curcgx.cgo.ms0=1;
   // dx,dy,dz
   dx=(curcgx.cgo.dpl[1].x-curcgx.cgo.dpl[0].x+1); // ACHTUNG
   dy=(curcgx.cgo.dpl[0].y-curcgx.cgo.dpl[1].y+1); // ACHTUNG
   dz=(curcgx.cgo.dpl[1].z-curcgx.cgo.dpl[0].z+1); // ACHTUNG
   if(dx<=0) { curcgx.cgo.dpl[0].x-=1; curcgx.cgo.dpl[1].x+=1; }
   if(dy<=0) { curcgx.cgo.dpl[1].y-=1; curcgx.cgo.dpl[0].y+=1; }
   if(dz<=0) { curcgx.cgo.dpl[0].z-=1; curcgx.cgo.dpl[1].z+=1; }

   //max,min
   max=(dx >=dy) ? dx  : dy;
   max=(max>=dz) ? max : dz;
   min=(dx <=dy) ? dx  : dy;
   min=(min<=dz) ? min : dz;
   coe=(min/(float)max);
   //printf("%f\n",coe);
   if(coe<0.5) {
      //printf("caught ");
      curcgx.cgo.dpl[0].y=curcgx.cgo.dpl[1].x;
      curcgx.cgo.dpl[1].y=curcgx.cgo.dpl[0].x;
      curcgx.cgo.dpl[0].z=curcgx.cgo.dpl[0].x;
      curcgx.cgo.dpl[1].z=curcgx.cgo.dpl[1].x;
   }

   #if(NDIMS==2)
   curcgx.cgo.nvzz=0; 
   curcgx.cgo.dpl[0].zz=0; 
   curcgx.cgo.dpl[1].zz=0;
   #endif
   // end -----------------------------------------------------------
   memcpy(&edp->cgar[ci],&curcgx,sizeof(Cgx));
   cvar=cvar;//dbg anchor
}
// Last inits
for(ci=0;ci<edp->cgarsz;ci++) {
   edp->cgar[ci].arpos = ci;
}

// Sorts by exord ?
cvar=cvar; //anchor
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
uchar Pop::Genvalid(int thid,int gen[],Guy *gyp) {
uchar res; int ci,dx,dy,dz;
Exbd *edp=exbd[thid];

res=YA;
Gendecoder(0,&gen[0],gyp,1);
for(ci=0;ci<edp->cgarsz;ci++) {
   if(edp->cgar[ci].exord!=-1) {
      dx=(edp->cgar[ci].cgo.dpl[1].x-edp->cgar[ci].cgo.dpl[0].x+1);
      dy=(edp->cgar[ci].cgo.dpl[0].y-edp->cgar[ci].cgo.dpl[1].y+1);
      dz=(edp->cgar[ci].cgo.dpl[1].z-edp->cgar[ci].cgo.dpl[0].z+1);
      if(dx<=0) res=NO; // useful for "external" proliferation
      if(dy<=0) res=NO; // useful for "external" proliferation
      if(dz<=0) res=NO; // useful for "external" proliferation
      //if(edp->cgar[ci].cgo.dpl[0].x>0) res=NO;
      //if(edp->cgar[ci].cgo.dpl[0].y>0) res=NO;
      //if(edp->cgar[ci].cgo.dpl[1].x<0) res=NO;
      //if(edp->cgar[ci].cgo.dpl[1].y<0) res=NO;
   }
}
return res;
}


