
#include "danxincl.h"

// Global var
extern Exbd  *exbd[NCORES];
extern Cvare *cve_[NCORES];

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Doper2(int thid,Cvare *cve,int gi,int as) {
char cvar=0;
int  ex,ey,ez,ri,mocnear[LFSPAN],ii,rx,ry,rz;
int  vx,vy,vz,dfound,nhx,nhy,nhz;
Coord vl,vu,el,eu;
Exbd *edp=exbd[thid];

// here considers only the first driver ([0])
ri=0; for(ii=0;ii<DHARLS;ii++) if(edp->drvaro[ii].x>=0) {
   ex=edp->drvaro[ii].x;
   ey=edp->drvaro[ii].y;
   ez=edp->drvaro[ii].z;
   memcpy(&edp->clardcd[ri],&edp->drvaro[ii],sizeof(Coord));
   edp->clard[ri++]=edp->clar[ex][ey][ez]; }
if(ri==0) goto GTPEOF;

nhx=DOP2NS; nhy=DOP2NS; 
nhz=0; if(NDIMS==3) nhz=DOP2NS;
memcpy(&vl,&edp->bbl,sizeof(Coord));
memcpy(&vu,&edp->bbu,sizeof(Coord));
Boundint(&vl.x,&vu.x,nhx+1,GRIDXX-nhx-2);
Boundint(&vl.y,&vu.y,nhy+1,GRIDYY-nhy-2);
Boundint(&vl.z,&vu.z,nhz+1,GRIDZZ-nhz-2);

// Plan B
// if clar[vx][vy][vz] is superficial and non-driver and in the vicinity
// no cell is superficial and driver ... then clar[vx][vy][vz] becomes driver
rx=-888; ry=-888; rz=-888;
cve->smocnew=SMOCMA;
//for(vx=nhx+1;vx<GRIDXX-nhx-1;vx++) 
//for(vy=nhy+1;vy<GRIDYY-nhy-1;vy++) 
//for(vz=nhz+1;vz<GRIDZZ-nhz-1;vz++) {
FORGRDCYC(vx,vy,vz,vl.x,vl.y,vl.z,vu.x,vu.y,vu.z) {
   if(edp->clar[vx][vy][vz].dhnrc3==65535) goto GTPXX0;
   // if "in interior grid" xy & z, non-void, borderline, NON-driver
   if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==0)
   if(Surfint(vx,vy,vz,edp)==YA) {
      // search neighbourhood, start ----------------
      dfound=NO;
      if(abs(rx-vx)<=nhx)
      if(abs(ry-vy)<=nhy)
      if(abs(rz-vz)<=nhz)
         dfound=YA;

      if(dfound==NO) {
         //for(ex=vx-nhx;ex<=vx+nhx;ex++)
         //for(ey=vy-nhy;ey<=vy+nhy;ey++) 
         //for(ez=vz-nhz;ez<=vz+nhz;ez++) {
         el.x = vx-nhx; eu.x = vx+nhx;
         el.y = vy-nhy; eu.y = vy+nhy;
         el.z = vz-nhz; eu.z = vz+nhz;
         FORGRDCYC(ex,ey,ez,el.x,el.y,el.z,eu.x,eu.y,eu.z) {
            if(edp->clar[ex][ey][ez].dhnrc3!=65535) {
               // if "in interior grid" xy&z,non-void,borderline,driver
               if(Lreader(Ldrv,&edp->clar[ex][ey][ez])==1)
               if(Surfint(ex,ey,ez,edp)==YA) {
                  dfound = YA;
                  rx = ex; // coords of found point
                  ry = ey; // coords of found point
                  rz = ez; // coords of found point
                  goto GTLAAA;
               }
            }
         }
      }
      GTLAAA:cvar=cvar;

      if(dfound==NO) {
         edp->tmpcoord.x = vx;
         edp->tmpcoord.y = vy;
         edp->tmpcoord.z = vz;
         Closedr(thid,cve,gi,ri,&mocnear[0]);
         cve->smocnew++;
         Dharupd (thid,cve,gi,&edp->cgxt,&mocnear[0],as,2,YA);
         Daughter(thid,cve,gi,-1,CLSLEEP,YA,-1);
         Dthrmnet(thid,cve,gi,-1,CLSLEEP,YA,-1);
      }
      // search neighbourhood, end ------------------
   }
   GTPXX0:cvar=cvar;
}

GTPEOF:cvar=cvar;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Closedr(int thid,Cvare *cve,int gi,int ri,int *moc) {
int  rj,rd,md,mda;
Exbd *edp=exbd[thid];
int ex = edp->tmpcoord.x;
int ey = edp->tmpcoord.y;
int ez = edp->tmpcoord.z;

md=(GRIDXX+GRIDYY+GRIDZZ); rd=-1;
for(rj=0;rj<ri;rj++) {
   mda=abs(edp->clardcd[rj].x-ex)
      +abs(edp->clardcd[rj].y-ey)
      +abs(edp->clardcd[rj].z-ez);
   if(md>mda) { md=mda; rd=rj; }}
Moccopy(&moc[0],&edp->dhar[Lreader(Ldhn,&edp->clard[rd])].moc[0]);
//moc=&edp->clard[rd]->moc[0];

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Gridinit(int thid,int gi) {
char str[20];
int  hi,ii,xi,ki,si;
int  vx,vy,vz,aiv,biv,an;
Exbd *edp=exbd[thid];

strcpy(str,"driver overflow");
edp->bbl.x = 9999; edp->bbu.x = -9999;
edp->bbl.y = 9999; edp->bbu.y = -9999;
edp->bbl.z = 9999; edp->bbu.z = -9999;

if(ISGRID==0) {
   for(ii=0;ii<ZYGTOT;ii++) {
      for(hi=0;hi<LFSPAN;hi++) edp->dhar[ii].moc[hi]=0;
		edp->dhar[ii].moc[LFSPAN-1]=ii;
		edp->dhar[ii].asval=-1;
      edp->dhnr=ii;
      vx=edp->zygx[ii]; vy=edp->zygy[ii]; vz=edp->zygz[ii];
      Lwriter(Lcnd,&edp->clar[vx][vy][vz],ii,+1,CLALIVE,0);

      // updates bound box
      if(vx < edp->bbl.x) edp->bbl.x = vx; 
      if(vy < edp->bbl.y) edp->bbl.y = vy; 
      if(vz < edp->bbl.z) edp->bbl.z = vz; 
      if(vx > edp->bbu.x) edp->bbu.x = vx; 
      if(vy > edp->bbu.y) edp->bbu.y = vy; 
      if(vz > edp->bbu.z) edp->bbu.z = vz;       
      
      #if(MNETON==YA)
      edp->clar[vx][vy][vz].mclvar=&edp->mxxxar[edp->dhnr];
      // oxarap
      for(xi=0;xi<OXARSZ;xi++)
         edp->clar[vx][vy][vz].mclvar->oxarap[xi]=1;
      for(ki=0;ki<2;ki++) for(si=0;si<SZSUSP;si++)
         edp->clar[vx][vy][vz].mclvar->iosmsk[ki][si]=3;
      #endif
   }
}
if(ISGRID==1) {
   edp->dhnr=0;
   for(vz=0;vz<GRIDZZ;vz++)
   for(vy=GRIDYY-1;vy>=0;vy--)
   for(vx=0;vx<GRIDXX;vx++) {
      aiv=edp->envr.etisooodp0grid[vx][vy][vz];
      biv=edp->envr.cdisooodp0grid[vx][vy][vz];
      if (aiv==-1) { // empty cells
      }
      if((aiv!=-1)&&(aiv< 30000)) { // normal cells
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],aiv,0,CLALIVE,biv);
      }
      if((aiv!=-1)&&(aiv>=30000)&&(aiv<60000)) { // cells asleep
         aiv-=30000;
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],aiv,0,CLALIVE,biv);
      }
      if((aiv!=-1)&&(aiv> 60000)) { // driver cells
         aiv-=60000;
         if(edp->dhnr>(int)pow((float)4,(float)CETXSQ))
            Leavexec(str);
         for(hi=0;hi<LFSPAN;hi++) edp->dhar[aiv].moc[hi]=0;
		   edp->dhar[aiv].moc[LFSPAN-1]=aiv;
         if(edp->dhnr<aiv) edp->dhnr=aiv;
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],aiv,+1,CLALIVE,biv);
      }
   }
}

// calc edp->ides
edp->ides = 0;
for(vx=0;vx<GRIDXX;vx++) 
   for(vy=0;vy<GRIDYY;vy++)  
      for(vz=0;vz<GRIDZZ;vz++) opened
         an = edp->envr.cdtgooodplgrid[vx][vy][vz];
         if(an!=-1) edp->ides += 1;
      closed

}

//!------------------------------------------------------------------
//! FCT
//!------------------------------------------------------------------
void  Body::Gridupd(int thid,int gi,int as,int us) {
int   pi,gy,vx,vy,vz;
int   aiv,biv,drv,clcnd;
float shad;
Exbd *edp=exbd[thid];

pi=gi/POPXSZ; gy=gi%POPXSZ;
// ACTUAL, as grids (aiv for dhnr, biv for conr)
if(((pi==0)&&(gy==0))||((pi==0)&&(gy==68))) FORVXYZ {
   aiv=-1; biv=-1;
   if (edp->clar[vx][vy][vz].dhnrc3!=65535) {
      drv  =Lreader(Ldrv,&edp->clar[vx][vy][vz]);
      clcnd=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
      if(clcnd==CLALIVE) aiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
      if(clcnd==CLALIVE) biv=Lreader(Lcol,&edp->clar[vx][vy][vz]);
      if(clcnd==CLSLEEP) aiv=Lreader(Ldhn,&edp->clar[vx][vy][vz])+30000;
      if(  drv==1      ) aiv=Lreader(Ldhn,&edp->clar[vx][vy][vz])+60000;
      if(clcnd==CLSLEEP) biv=Lreader(Lcol,&edp->clar[vx][vy][vz]);
      if(clcnd==CLNOCEL) aiv=-1;
      if(clcnd==CLNOCEL) biv=-1;
      if(clcnd==CLNOCL0) aiv=-2;
      if(clcnd==CLNOCL0) biv=-1;
   }
   if(gi==0) if(thid==0) edp->envr.ooacooodpagrid[as][vx][vy][vz].d0=aiv;
 //if(gi==1) if(thid==0) edp->envr.ooacooodpagrid[as][vx][vy][vz].dd=aiv;
   if(gi==0) if(thid==0) edp->envr.ooacooodpagrid[as][vx][vy][vz].e0=biv;
 //if(gi==1) if(thid==0) edp->envr.ooacooodpagrid[as][vx][vy][vz].ee=biv;
}

// epacgyxdsxgrid is updated elsewhere

}

//!------------------------------------------------------------------
//! Fnctheader
//!------------------------------------------------------------------
float Body::Fitboxy(int thid,int gi) {
char  cvar=0;
int   pi,gy,vx,vy,vz;
int   aiv,biv,ci,ides,iins,ious;
float shad,bdes,bins,bous;
float cins,xins,cinsar[COLORS],shco0,afv;
Exbd  *edp=exbd[thid];

pi=gi/POPXSZ; gy=gi%POPXSZ;
ides = edp->ides; iins=0; ious=0; 
for(ci=0;ci<COLORS;ci++) { cinsar[ci]=0; }
//FORVXYZ {
for(vx=edp->bbl.x;vx<=edp->bbu.x;vx++) 
for(vy=edp->bbl.y;vy<=edp->bbu.y;vy++) 
for(vz=edp->bbl.z;vz<=edp->bbu.z;vz++) {
   aiv=edp->envr.cdtgooodplgrid[vx][vy][vz];
   if(edp->clar[vx][vy][vz].dhnrc3==65535) biv=-1; // For speed
   else biv=
      ((Lreader(Lcnd,&edp->clar[vx][vy][vz])==CLALIVE) ||
       (Lreader(Lcnd,&edp->clar[vx][vy][vz])==CLSLEEP)) ?
        Lreader(Lcol,&edp->clar[vx][vy][vz]):-1;   // color code
   if((aiv!=-1)&&(biv!=-1)) iins++;
   if((aiv==-1)&&(biv!=-1)) ious++;
   if((aiv!=-1)&&(biv!=-1)) {
      afv=(float)(abs(aiv-biv));
      if(afv<FITTOL)
         cinsar[aiv]+=1-(float)0.7*(afv/FITTOL);
   }
}

// float conv
bdes=(float)ides;
bins=(float)iins;
bous=(float)ious;

cvar=cvar;//anchor
cins=0;
for(ci=0;ci<COLORS;ci++) { cins+=cinsar[ci]; }
// calc
shco0=(float)SHCOE0;
if(edp->cn<=(18000*AMSGECOE))
   shco0*=(float)(edp->cn/(18000*AMSGECOE));
shco0=(float)SHCOE0;
xins=(float)((1-shco0)*bins+(shco0)*cins);

// calc shad
if (bdes==0) shad=-1;
else {
   shad=(float)(xins-SHCOE2*bous)/bdes;
   if(shad<0) shad=0;
}

return shad;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void  Body::Showres(int thid,FILE *fptr00,char *atmpstr) {
int   gi,pi,gy,ii,nshowed,*ord;
float *par,shad,gaft,mfit;
float gaftavg[NPOPS],shadavg[NPOPS],mfitavg[NPOPS],shadbst;
Exbd  *edp=exbd[thid];

ord=( int *)malloc(sizeof( int )*edp->popa[0]->popsz);
par=(float*)malloc(sizeof(float)*edp->popa[0]->popsz);

nshowed=SHOWED;
for(pi=0;pi<NPOPS;pi++) {
   for(gy=0;gy<edp->popa[pi]->popsz;gy++)
      par[gy]=edp->popa[pi]->guys[gy].gaft;
   Mysortxxxx(&par[0],edp->popa[pi]->popsz,0,&ord[0]);
   for(ii=0;ii<nshowed;ii++) {
      gaft=edp->popa[pi]->guys[ord[ii]].gaft*100;
      shad=edp->popa[pi]->guys[ord[ii]].shad*100;
      mfit=edp->popa[pi]->guys[ord[ii]].mfit*100;
      if(pi==0)if(ii==0) shadbst=shad;
      strcpy(atmpstr,
         "\nBEST %3d) (%3d) gaft: %5.2f shad: %5.2f mfit: %5.2f ");
      fprintf(stdout,atmpstr,ii,ord[ii],gaft,shad,mfit);
      fprintf(fptr00,atmpstr,ii,ord[ii],gaft,shad,mfit);
   }
   // avg
   gaftavg[pi]=0; shadavg[pi]=0; mfitavg[pi]=0;
   for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
      gaftavg[pi]+=edp->popa[pi]->guys[gy].gaft;
      shadavg[pi]+=edp->popa[pi]->guys[gy].shad;
      mfitavg[pi]+=edp->popa[pi]->guys[gy].mfit;
   }
   gaftavg[pi]=gaftavg[pi]*100/POPXSZ;
   shadavg[pi]=shadavg[pi]*100/POPXSZ;
   mfitavg[pi]=mfitavg[pi]*100/POPXSZ;
   strcpy(atmpstr,"   AVG gaft: %5.2f shad: %5.2f mfit: %5.2f ");
   fprintf(stdout,atmpstr,gaftavg[pi],shadavg[pi],mfitavg[pi]);
   fprintf(fptr00,atmpstr,gaftavg[pi],shadavg[pi],mfitavg[pi]);
}

free(ord);
free(par);

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void  Body::Calcfit(int thid) {
int   pi,gy,ord[NPOPS];
float fitmix,shad,mfit; 
Exbd  *edp=exbd[thid];

// assigns gaft
for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   shad=edp->popa[pi]->guys[gy].shad;
   mfit=edp->popa[pi]->guys[gy].mfit;
   edp->popa[pi]->guys[gy].gaft=shad;
   #if(MNETON==YA)
   fitmix=(float)FITMIX;
   edp->popa[pi]->guys[gy].gaft = shad*(1-fitmix)+mfit*fitmix;
   #endif
}

// temporary crowning (each pop)
for(pi=0;pi<NPOPS;pi++) { 
   edp->bsooar[pi]=-1; 
   edp->bsguys[pi]=NULL; 
}
for(pi=0;pi<NPOPS;pi++)
for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   if(edp->bsooar[pi]< edp->popa[pi]->guys[gy].gaft) {
      edp->bsooar[pi]= edp->popa[pi]->guys[gy].gaft;
      edp->bsguys[pi]=&edp->popa[pi]->guys[gy];
   }
}

// Transplants best guys in pos 0 of pops in decreasing order
for(pi=0;pi<NPOPS;pi++) ord[pi]=pi;
Mysortxxxx(&edp->bsooar[0],NPOPS,0,&ord[0]);
for(pi=0;pi<NPOPS;pi++)
   memcpy(&edp->ordgys[pi],edp->bsguys[ord[pi]],sizeof(Guy));
for(pi=0;pi<NPOPS;pi++)
   memcpy(&edp->popa[pi]->guys[0],&edp->ordgys[pi],sizeof(Guy));

#if(NICHEX==YA)
int pres,cgarszx;
int riv,siv,ci,gi,dj,pj;
int mosr[LFSPAN],moss[LFSPAN];
float eh,dh,sh,mh;
Cgx **cgarh;

cgarh=(Cgx**)malloc(sizeof(Cgx*)*NNGUYS);
for(gi=0;gi<NNGUYS;gi++) 
   cgarh[gi]=(Cgx*)malloc(sizeof(Cgx)*CGARSZ);

for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   gi=pi*POPXSZ+gy;
   edp->popa[pi]->Gendecoder(0,edp->popa[pi]->guys[gy].gen,NULL,1);
   for(ci=0;ci<edp->cgarsz;ci++)
      memcpy(&cgarh[gi][ci],&edp->cgar[ci],sizeof(Cgx));
}

// ET-based niching
for(pi=1;pi<NPOPS;pi++) {
   edp->bsooar[pi]=-1; edp->bsguys[pi]=NULL;
   for(gy=0;gy<edp->popa[pi]->popsz;gy++) { //skips 1st pop
      mh=0;
      for(pj=0;pj<pi;pj++) {
         // now compares 2 cgar
         eh=0; cgarszx=0;
         //for(ci=0;ci<cgarsz;ci++) {
         for(ci=edp->frz[edp->gq].xf;ci<edp->frz[edp->gq].xe;ci++) {
            if(memcmp(&cgarh[pi*edp->popa[pi]->popsz+gy][ci].mos[0],
               &edp->moc0,sizeof(int)*LFSPAN)) {
               cgarszx++; pres=NO;
               //for(dj=0;dj<cgarsz;dj++) {
               for(dj=edp->frz[edp->gq].xf;dj<edp->frz[edp->gq].xe;dj++) {
                  riv=pi*edp->popa[pi]->popsz+gy;
                  siv=pj*edp->popa[pj]->popsz+ 0;
                  //mosr=&cgarh[pi*edp->popa[pi]->popsz+gy][ci].mos[0];
                  //moss=&cgarh[pj*edp->popa[pj]->popsz+ 0][dj].mos[0];
                  memcpy(&mosr[0],&cgarh[riv][ci].mos[0],
                     sizeof(int)*LFSPAN);
                  memcpy(&moss[0],&cgarh[siv][dj].mos[0],
                     sizeof(int)*LFSPAN);
                  if((memcmp(mosr,moss,sizeof(int)*LFSPAN))==0) pres=YA;
               }
               if(pres==YA) eh++;
            }
         }
         eh/=cgarszx;                            // eh: % equal
         dh=1-eh;                                // dh: % different
         sh=1-(float)pow(dh/NICHESS,NICHEA);     // sh: % equal
         mh+=(sh);                               // normalise
      }
      #if(MNETON==NO)
      edp->popa[pi]->guys[gy].gaft=edp->popa[pi]->guys[gy].shad/(mh+1);
      #endif
      #if(MNETON==YA)
      fitmix=(float)FITMIX;
      shad=edp->popa[pi]->guys[gy].shad;
      mfit=edp->popa[pi]->guys[gy].mfit;
      edp->popa[pi]->guys[gy].gaft = 
         (shad*(1-fitmix)+mfit*fitmix)/(mh+1);
      #endif
      // final crowning
      if(edp->bsooar[pi]< edp->popa[pi]->guys[gy].gaft) {
         edp->bsooar[pi]= edp->popa[pi]->guys[gy].gaft;
         edp->bsguys[pi]=&edp->popa[pi]->guys[gy];
      }
   }
   // final crowning
   ord[pi]=pi; Mysortxxxx(&edp->bsooar[0],NPOPS,0,&ord[0]);
   memcpy(&edp->ordgys[pi],edp->bsguys[ord[pi]],sizeof(Guy));
   memcpy(&edp->popa[pi]->guys[0],&edp->ordgys[pi],sizeof(Guy));
}

for(gi=0;gi<NNGUYS;gi++) free(cgarh[gi]);
free(cgarh);
#endif

}

//!------------------------------------------------------------------
//! function header
//!------------------------------------------------------------------
Body::Body(void) {}

//!------------------------------------------------------------------
//! function header
//!------------------------------------------------------------------
void  Body::Bodinit(int ei) {
int   gi,pi,ci,vx,vy,vz;
int   cx,ii,di,si,hi;
int   val,aa,bb;
Exbd *edp=exbd[ei];

// frz
double gearx[NAMS]=AMSGEX; double xfarx[NAMS]=AMSXFX;
double xearx[NAMS]=AMSXEX; double dparx[NAMS]=AMSLSX;
double uparx[NAMS]=AMSUSX; double dlarx[NAMS]=AMSDLX;
double fsarx[NAMS]=AMSFSX;
for(ii=0;ii<NAMS;ii++) {
   edp->frz[ii].ge =(int)(gearx[ii]*1000*AMSGECOE);
   edp->frz[ii].xf =(int) xfarx[ii];
   edp->frz[ii].xe =(int) xearx[ii];
   edp->frz[ii].ls =(int) dparx[ii];
   edp->frz[ii].us =(int) uparx[ii];
   edp->frz[ii].dl =(int) dlarx[ii];
   edp->frz[ii].fs =(int) fsarx[ii];
}

#if(DEBUG0==YA)
if(ei==0) {
   printf("edp->frz[]\n");
   for(ii=0;ii<NAMS;ii++) {
      printf("%3d",edp->frz[ii].dl); 
      if((ii+1)%10==0) printf("\n"); }
   printf("\n");
}
#endif

// xqar
for(ci=0;ci<CGARSZ;ci++) {
   val=ci;
   for(ii=-1;ii<NAMS-1;ii++) {
      if(ii==-1) { aa=0;               bb=edp->frz[0].xe;    }
      else       { aa=edp->frz[ii].xe; bb=edp->frz[ii+1].xe; }
      if(((aa<=val)&&(val<bb))) { edp->xqar[ci]=ii+1; break; }
   }
}

// cgarsz,cn,cn0,clarf
edp->cgarsz=CGARSZ;
edp->cn=0; edp->cn0=0;

// Other var
for(pi=0;pi<NPOPS;pi++) {
   edp->bsooar[pi]=0;
   edp->bsguys[pi]=NULL;
}

// shadhst
for(gi=0;gi<NNGUYS;gi++) 
   for(ii=0;ii<FITHST;ii++) 
      for(hi=0;hi<LFSPAN;hi++) 
         edp->shadhst[gi][ii][hi] = 0;

// fithst,zyg
int zygsss[12] = ZYGSSS;
for(ii=0;ii<4;ii++) {
   edp->zygx[ii]=zygsss[3*ii+0];
   edp->zygy[ii]=zygsss[3*ii+1];
   edp->zygz[ii]=zygsss[3*ii+2];
}

// Exdp various
FORVXYZ Clsrinit(&edp->clar [vx][vy][vz],CLNOCEL);
//FORVXYZ Clsrinit(&edp->claro[vx][vy][vz],CLNOCEL);
for(cx=0;cx<DHARLS;cx++) Clsrinit(&edp->clard[cx],CLNOCEL);
Clsrinit(&edp->moclp,CLNOCEL);
for(ci=0;ci<edp->cgarsz;ci++) {
   memcpy(&edp->cgar  [ci],&edp->cgxt,sizeof(Cgx));
   memcpy(&edp->cgare [ci],&edp->cgxt,sizeof(Cgx));
   memcpy(&edp->cgaro [ci],&edp->cgxt,sizeof(Cgx));
}

// Mnet 
edp->oxarsz = OXARSZ;  // init
for(di=0;di<DHARLS;di++) {
   for(ii=0;ii<2;ii++) for(si=0;si<SZSUSP;si++)
      edp->mxxxar[di].iosmsk[ii][si]=0;
   for(si=0;si<OXARSZ;si++) edp->mxxxar[di].oxarap[si]=0;
   edp->mxxxar[di].olrxxx=-1;
}
// Mnet-end 

// rrorder 
// code removed
}

//!------------------------------------------------------------------
//! function header
//!------------------------------------------------------------------
void Body::Initlocv (int thid) {
int  ii,hi;
Exbd *edp=exbd[thid];

// Inits guyt, dpelt, clt
edp->guyt.neugy=YA; 
edp->guyt.gaft=0; edp->guyt.shad=-1;
memset(&edp->guyt.gen,0,sizeof(int)*GENXSZ);
edp->dpelt.d0=-1; edp->dpelt.e0=-1;
for(hi=0;hi<LFSPAN;hi++) edp->moct[hi]=-1;
edp->clt = new Cell(NULL,&edp->moct[0],CLNOCEL);

// Inits cst
Lwriter(Lxxx,&edp->cst,-1,-1,CLNOCEL,-1);
edp->cst.dhnrc3=65535;
#if(MNETON==YA)
edp->cst.mclvar=NULL;
#endif

// Inits cgot
edp->cgot.ms0=-1; edp->cgot.shp=-1; edp->cgot.conr=-1;
for(ii=0;ii<2;ii++) {
   edp->cgot.dpl[ii].x=-1;
   edp->cgot.dpl[ii].y=-1;
   edp->cgot.dpl[ii].z=-1;
}

// Inits cgxt
edp->cgxt.exord=-1;
edp->cgxt.on   =-1;
edp->cgxt.as   =-1;
edp->cgxt.arpos=-1;
for(hi=0;hi<LFSPAN;hi++) edp->cgxt.mos[hi]=-1;
memcpy(&edp->cgxt.cgo,&edp->cgot,sizeof(Cgo));

// Inits cget
memcpy(&edp->cget.cgx,&edp->cgxt,sizeof(Cgx));
for(hi=0;hi<LFSPAN;hi++) edp->cget.moc[hi]=-1;
edp->cget.ncells=0; edp->cget.asval=-1;

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Envinit(int thid,int opt) {
char cvar=0;
int  as,vx,vy,vz;
Exbd *edp=exbd[thid];

if(opt==0) {
   if   (thid==00) edp->envr.ooacooodpagrid
      =(Dpel****)malloc(sizeof(Dpel***)*LFSPAN );
   for(as=0;as<LFSPAN;as++) {
      if(ISGRID!=1) goto GTL000;
      if(as  ==00) edp->envr.etisooodp0grid
      =(int  ***)malloc(sizeof(int  **)*GRIDXX);
      if(as  ==00) edp->envr.cdisooodp0grid
      =(int  ***)malloc(sizeof(int  **)*GRIDXX);
      GTL000:cvar=cvar;
      if(as  ==00) edp->envr.cdtgooodplgrid
      =(int  ***)malloc(sizeof(int  **)*GRIDXX);
      if(thid==00) edp->envr.ooacooodpagrid[as]
      =(Dpel ***)malloc(sizeof(Dpel **)*GRIDXX);
   }
   for(as=0;as<LFSPAN;as++) for(vx=0;vx<GRIDXX;vx++) {
      if(ISGRID!=1) goto GTL001;
      if(as  ==00) edp->envr.etisooodp0grid    [vx]
      =(int   **)malloc(sizeof(int   *)*GRIDYY);
      if(as  ==00) edp->envr.cdisooodp0grid    [vx]
      =(int   **)malloc(sizeof(int   *)*GRIDYY);
      GTL001:cvar=cvar;
      if(as  ==00) edp->envr.cdtgooodplgrid    [vx]
      =(int   **)malloc(sizeof(int   *)*GRIDYY);
      if(thid==00) edp->envr.ooacooodpagrid[as][vx]
      =(Dpel  **)malloc(sizeof(Dpel  *)*GRIDYY);
   }
   for(as=0;as<LFSPAN;as++) for(vx=0;vx<GRIDXX;vx++) for(vy=0;vy<GRIDYY;vy++){
      if(ISGRID!=1) goto GTL002;
      if(as  ==00) edp->envr.etisooodp0grid    [vx][vy]
      =(int    *)malloc(sizeof(int    )*GRIDZZ);
      if(as  ==00) edp->envr.cdisooodp0grid    [vx][vy]
      =(int    *)malloc(sizeof(int    )*GRIDZZ);
      GTL002:cvar=cvar;
      if(as  ==00) edp->envr.cdtgooodplgrid    [vx][vy]
      =(int    *)malloc(sizeof(int    )*GRIDZZ);
      if(thid==00) edp->envr.ooacooodpagrid[as][vx][vy]
      =(Dpel   *)malloc(sizeof(Dpel   )*GRIDZZ);
   }
}

// Inits
if(opt==0) {
   for(as=0;as<LFSPAN;as++) FORVXYZ {
      if(ISGRID!=1) goto GTL003;
      if(as  ==00) edp->envr.etisooodp0grid[vx][vy][vz]=0;      // ACHTUNG
      if(as  ==00) edp->envr.cdisooodp0grid[vx][vy][vz]=0;      // ACHTUNG
      GTL003:cvar=cvar;
      if(as  ==00) edp->envr.cdtgooodplgrid[vx][vy][vz]=0;      // ACHTUNG
      if(thid==00) memcpy(&edp->envr.ooacooodpagrid[as][vx][vy][vz],
         &edp->dpelt,sizeof(Dpel));
   }
}

}

