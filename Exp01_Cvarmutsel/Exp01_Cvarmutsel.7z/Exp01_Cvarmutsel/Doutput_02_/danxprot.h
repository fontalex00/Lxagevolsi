
// Fwd declarations
class Pop; class Cell; class Body;

typedef unsigned char uchar;

typedef struct {
   int x,y,z;
}  Coord;

typedef struct {
   uchar neugy;
   int   gen[GENXSZ];
   float gaft,shad,mfit;
   // gaft: GA fitness, shad: shape adherence
}  Guy;

typedef struct {
   int bval; int flag;
}  Gnpbase;

typedef struct {
   int d0,e0; //int d0,dd,ds,e0,ee,ms;
}  Dpel;

typedef struct {
   int ms0,ms1,dgd[9],conr,c2nr,shp,car[8];    
   //shape (car: chemo-attractant
   int olrxxx,iosmsk[2][SZSUSP],oxrchd[OXRCHD];
   //metab receptor)
   Coord  dpl[2];
}  Cgo; // Change instruction's output

typedef struct {
   int exord,on,as,mos[LFSPAN],arpos,napos,fsc;
   Cgo cgo;
}  Cgx; // Change instruction

typedef struct {
   Cgx cgx;
   int ncells,asval,moc[LFSPAN];
}  Cge; // Change event

typedef struct {
   int ge,xf,xe,ls,us,dl,fs; // up: upper phase
}  Frz;

// Mnet ---------------------------------------------------
typedef struct {
   int   act,oxarpos;
   int   isui[MAXIPS],osui; // i/osui: i/o substance identifier
   float whts[MAXIPS+1],ival[MAXIPS],oval;
   int   lrxx; int cndx; int oxcd;
}  Oxr; // cndx:=-1 if never evolved, =0 if not active, =1 if active

typedef struct {
   int   olrxxx,oxarap[OXARSZ];
   int   iosmsk[2][SZSUSP]; //outside lr, i/o sub. mask
}  Mcl; // Mcl: metabolic cell.         // oxar act. pat.

typedef struct {
   Coord iopar[2][1]; // point coords in whose nbhood drivers are searched
   Coord iodar[2][1]; // point coords in which closest drivers are
   float iotar[2][EXARSZ][SZSUSP];
}  Mtv; // Mtv: metabolic target values
// Mnet_end -----------------------------------------------

typedef struct {
   unsigned short dhnrc3;
   unsigned char drv;
   unsigned char cnd;
   unsigned char col;
   #if(MNETON==YA)
   Mcl *mclvar; // sostituire con mclnr (int): posizione in mxxxar
   #endif
}  Clsr; // Cell struct

typedef struct {
   int   dhnrc2;
   Coord coords;
}  Clsz; // Cell struct type "z"

typedef struct {
   // Target
   int ***   etisooodp0grid;
   int ***   cdisooodp0grid;
   int ***   cdtgooodplgrid;
   // Actual, as grids
   Dpel****  ooacooodpagrid;
   Mtv  mtv;
}  Envir;

typedef struct {
   // --- xxxxxxxx 
   Pop    *popa[NPOPS];
   Envir  envr;
   Clsr   clar [GRIDXX][GRIDYY][GRIDZZ];
   Clsr   clard[DHARLS],moclp;
   Clsr   clar0[GRIDXX][GRIDYY][GRIDZZ];
   Clsz   claro[SZGRID];
   Coord  clardcd[DHARLS];
   Coord  bbl,bbu,tmpcoord,motcoord;
   Cge    dhar[DHARLS];
   int    dhnr,ides;
   long   t0,t1;
   // --- Dvarprep & chx sort 
   Cgx    cgar[CGARSZ],cgaro[CGARSZ],cgare[CGARSZ];
   int    cgarxf,cgarsz,cgarszo,cgarsze;
   int    ordaux[CGARSZ];
   float  scorar[CGARSZ],par[CGARSZ];
   // --- arrays of drivers 
   int    cndaro[DHARLS];
   Coord  drvaro[DHARLS];
   // --- movie (code removed) --------------------------------------
   // --- initial values
   int    moct[LFSPAN]; Guy guyt;
   Cell   *clt; Clsr cst; Dpel dpelt;
   Cgo    cgot; Cgx cgxt; Cge cget; 
   // --- xxxxxxxx --------------------------------------------------
   Frz    frz[NAMS];
   int    zygx[4],zygy[4],zygz[4];
   int    ausdr,cn,cn0,gq,xq;
   int    ff,fset,xqar[CGARSZ],fdone;
   int    pnr;
   // --- Calcfit
   float  bsooar[NPOPS]; // serial, only exbd[0]. used
   Guy    *bsguys[NPOPS],ordgys[NPOPS]; // serial, only exbd[0]. used
   float  shadhst[NNGUYS][FITHST][LFSPAN];
   float  tcoefar[LFSPAN],pmutar[LFSPAN]; 
   // --- "first" vars
   int    sr,dhnrf,dhnro,mocdvf[DHARLS][LFSPAN];
   #if(MOCDEV==YA)
   Cge    dharal[NNGUYS][DHARLS],dharaltemp[DHARLS];
   int    dhnral[NNGUYS],dhnraltemp;
   #endif
   Cge    dharf [DHARLS],*dharo; // use: freq wr
   Cgx    cgarf [CGARSZ];
   Coord  drvarf[DHARLS];
   int    evtnrf[LFSPAN],evtnr[LFSPAN];
   Guy    guyf;
   // --- "base" vars 
   int    dhnrb;
   Clsr   clarb[GRIDXX][GRIDYY][GRIDZZ];
   Cge    dharb[DHARLS];
   // Mnet ----------------------------------------------------------
   int    oxarsz;
   Oxr    oxar  [OXARSZ]; // operational vs of oxar
   Mcl    mxxxar[DHARLS]; // metabolic cell array
   Clsr  *drvarh[DHARLS],*drvark[DHARLS]; // ar of drivers (ptr)
   float  lrordh[DHARLS], lrordk[DHARLS]; // 'layer' parameters and aux ar
   Coord  drvcdh[DHARLS], drvcdk[DHARLS];
   int    auxarr[DHARLS]; // lr sort
   float  **drvdst;
   Mcl    momcl;
   float  intsbc[DHARLS][SZSUSP],extsbc[DHARLS][SZSUSP]; // int & ext sub cnc
   float  extsc0[EXARSZ][DHARLS][SZSUSP]; // external subst. concentrations
   int    oxarp0[DHARLS][OXARSZ]; // operators' activations
}  Exbd; // Ex body functions (global BUT PRIVATE: each process has a copy)

typedef struct {
   Coord  dpl[8];
   int    cgok,clok,vvi[8],vvj[8],smocnew;
   int    buf0[2*DPLMAX][2*DPLMAX][2*DPLMAX];
   float  rt[9],hex,hey,hez;  // rt: rotation matrix
}  Cvare; // common var "e"

// AUX FCTS
void   Boundint(int *xl,int *xu,int bl,int bu);
float  Bsigmoid(float x,float sl,float ts);
void   set_fpu (unsigned int mode);
int    Intpower(int bb,int ee);
void   Mysortxxxx(float par[],int szar,int opt,int ord[]);
void   Mysortxcgx(int thid,float par[],int szar,int opt,
                  Cgx *dvardst,Cgx *dvarsrc);
void   Mysortlrxx(int thid,float par[],int szar,int opt,
                  Clsr *drvard[],Clsr *drvars[]);
void   Gencpy(int gen1[],int gen0[],int b0,int ncopied);
void   Leavexec(char *str);
void   Cvbase2int(int basear[],int   *ndec0,int szar,int base,int *arind);
void   Cvint2base(int basear[],int   *ndec0,int szar,int base,int *arind);
void   Cvbase2flt(int basear[],float *nflt0,int szar,int base,int *arind);
void   Varrescale(int *var,int scale0,int scale1);
int    Mocmatch (int *mos,int *moc,int naposmin,int fscmax,
                 int *napos,int *fsc);
void   Moccopy(int mocd[],int mocs[]);
void   Printf4(FILE *fptr, const char *fmt, ...);
int    Lreader(int par,Clsr *clp);
void   Lwriter(int par,Clsr *clp,int dhnneu,int drvneu,int cndneu,int colneu);
float  Max3(float n0,float n1,float n2);
int    Rnd1(int rnmax);
int    Rnds(int rnmax);
float  Sigmoid0(float xx,float ss);
int    Surfint(int xx,int yy,int zz,Exbd *edp); // surface interior
void   Setedges(Coord *e0,Coord *e7,Coord e[]);
int    Getthid(Exbd **edpp);
void   Mpscpy(char *sndbuf, void *srcdat, int size, int *cnt);
void   Mprcpy(void *dstdat, char *recbuf, int size, int *cnt);
void   FileMerger();
// Aux fcts: debug & temporary

//!------------------------------------------------------------------
//! header
//!------------------------------------------------------------------
class Pop {
/*VARS*/ public:
Body    *popbdp;
int     dnaxf,dnasz,popsz,spopsz0,spopsz1,nkids0,nkids1;
Gnpbase dnp[GENXSZ];
Guy     guys[POPXSZ],*chmp;
/*FCTS*/ public:
void Genrnd(int thid,int ngen);
void Reproduction(int thid,int sons);
void Decimation(int thid,int ndeads, uchar deathtype);
void Crossover(int thid,float pcross);
void Mutation(int thid);
void Gycp (int opt,Guy gard[],Guy gars[],int gd,int gs,int n);
void Galoop(int thid,int opt);
Pop (int thid,Body * bdp);
virtual void Gendecoder(int thid,int gen[],Guy *gyp,int opt);
//virtual void Genoocoder(int gen[]);
virtual uchar Genvalid(int thid,int gen[],Guy *gyp);
virtual void Cons(int thid,Body * _popbdp);
};

//!--------------------------------------------------------------------------
//! header
//!--------------------------------------------------------------------------
class Cell {
/*VARS*/ public:
Body *clbdp;
int clcnd,dhnrc,conr,drv; // drv: driver
/*FCTS*/ public:
Cell(Body * bdp,int *_moc,int _clcnd);
void Cellinit  (int *_moc,int _clcnd);
};

//!------------------------------------------------------------------
//! header
//!------------------------------------------------------------------
class Body { // all these vars are (should be) shared by all threads
/*Vars*/ public:

/*FCTS*/ public:
// FILE 1: high-level and init
void Baseloop(int opt,Body *bdp);
void Devoloop(int *gip,int gu);
// FILE 2: geometry-related & auxiliary
void Cgarprep(int thid,Cvare *cve,int gi,int as,int ss); // ss: start step
void Shaper  (int thid,Cvare *cve,int gi,int as,int us);
void Movie   (int thid,Cvare *cve,int gi,int as,int us);
void Brush   (int thid,Cvare *cve,int gi,int as,int ci);
void Clset   (int thid,Cvare *cve,int gi,int as,int ci);
void Dharupd (int thid,Cvare *cve,int gi,Cgx *cgx,int moc[],int asval,
              int clr,int drv);
void Daughter(int thid,Cvare *cve,int gi,int ci,
              int clcnd,int drv,int dhnrnor);
void Dthrmnet(int thid,Cvare *cve,int gi,int ci,
              int clcnd,int drv,int dhnrnor);
void Calcageprof(int thid,int repstep);
// FILE 3: xxxx
void Doper2  (int thid,Cvare *cve,int gi,int as);
void Closedr (int thid,Cvare *cve,int gi,int ii,int*moc);
void Gridinit(int thid,int gi);
void Gridupd (int thid,int gi,int as,int us);
float Fitboxy(int thid,int gi);
void Showres (int thid,FILE *fpb,char *atmpstr);
void Calcfit (int thid);
// FILE 3: init
Body(void);
void Bodinit (int thid);
void Initlocv(int thid);
void Envinit (int thid,int opt);
// FILE 4: load and save
void Loadgrid(int thid,char * file, int opt);
void Loadmemo(int thid);
void Savememo(int thid);
void Savevtk (int thid,int hi, char *filename);
void Savegrd (int thid,int hi, char *filename);
// FILE 4: genome manipulation
void Prexline(int thid);
void Germline(int thid);
void Genchger(int gy,int gen[],Cgx *curcgx);
// FILE 4: Init and auxx
void Clsrinit(Clsr *cs,int _clcnd);
void Copyclsr(Clsr *csd,Clsr *css);
void Moveclsr(int thid,Clsr *csd,Clsr *css);
// FILE 4: Mnet
void Mnetcalc(int thid,int gi);
};


