
#include "danxincl.h"

// Global var
extern Exbd  *exbd[NCORES];
extern Cvare *cve_[NCORES];

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Cgarprep(int thid,Cvare *cve,int gi,int as,int ss) {
char  cvar=0;
int   vx,vy,vz,ci,ii;
int   ntypes,res,res1,nap,fsc,aiv,oiv,cnd;
float afv;
Exbd *edp=exbd[thid];

for(ii=0;ii<DHARLS;ii++) {
   if(edp->cndaro[ii]==CLNOCL0) edp->cndaro[ii] = CLNOCEL;
   if(edp->cndaro[ii]==CLSLEEP) edp->cndaro[ii] = CLALIVE;
}

// Inits 
for(ci=0;ci<edp->cgarsz;ci++) 
   memcpy(&edp->cgare[ci],&edp->cgxt,sizeof(Cgx));
for(ci=0;ci<edp->cgarsz;ci++) edp->scorar[ci]=-1;
if(as==ss) for(ii=0;ii<DHARLS;ii++) edp->drvaro[ii].x=-1;
if(as==ss) for(ii=0;ii<DHARLS;ii++) edp->cndaro[ii]=CLNOCEL;

//FORVXYZ {
for(vx=edp->bbl.x;vx<=edp->bbu.x;vx++) 
for(vy=edp->bbl.y;vy<=edp->bbu.y;vy++) 
for(vz=edp->bbl.z;vz<=edp->bbu.z;vz++) {
   if(edp->clar[vx][vy][vz].dhnrc3!=65535) {
      cnd=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
      if(cnd==CLSLEEP)
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],-1,-1,CLALIVE,-1);
      if(cnd==CLNOCL0)
         edp->clar[vx][vy][vz].dhnrc3=65535;
       //Lwriter(Lxxx,&edp->clar[vx][vy][vz],-1,-1,CLNOCEL,-1);
      if(as!=ss) goto GTLEOB;
      if((cnd==CLSLEEP)||(cnd==CLALIVE))
      if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==1) {
         oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
         edp->drvaro[oiv].x=vx;
         edp->drvaro[oiv].y=vy;
         edp->drvaro[oiv].z=vz;
         edp->cndaro[oiv]=CLALIVE;
      }
      GTLEOB:cvar=cvar;
   }
}

// Sorts by exord
afv=(float)Intpower(4,OPXXSQ)-1;
for(ci=0;ci<edp->cgarsz;ci++)
   edp->par[ci]=(float)edp->cgar[ci].exord/afv;
Mysortxcgx(thid,edp->par,edp->cgarsz,1,edp->cgare,edp->cgar);
edp->cgarsze=edp->cgarsz;

// eliminates inactive, undue & "colour" genes
memcpy(&edp->cgaro[0],&edp->cgare[0],sizeof(Cgx)*edp->cgarsz);
edp->cgarszo=edp->cgarsze; edp->cgarsze=0;
aiv=edp->frz[edp->gq].fs;
for(ci=0;ci<edp->cgarszo;ci++)
   if((edp->cgaro[ci].on!=-1)&&(edp->cgaro[ci].on!=0))
   if((edp->cgaro[ci].as==-1)||(as==edp->cgaro[ci].as))
   if((edp->frz[edp->xqar[edp->cgaro[ci].arpos]].us>=as)||(as>aiv))
   if((edp->cgaro[ci].cgo.ms0>=0)&&(edp->cgaro[ci].cgo.ms0<=MS0MAX))
      memcpy(&edp->cgare[edp->cgarsze++],&edp->cgaro[ci],sizeof(Cgx));

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void  Body::Shaper(int thid,Cvare *cve,int gi,int as,int us) {
char  cvar=0,str[20];
int   vx,vy,vz,ci,cgoknr,evtnr;
int   matched,ri,ii,mx,my,mz,ivaro;
int   res,nap,fsc;
float max,min,coe;
Coord *dpla; Clsr curcl;
Exbd  *edp=exbd[thid];

strcpy(str,"ahi ahi restore");
#if(DEBUG0==YA)
if(as==1)
   cvar=cvar;
#endif

#if(ZSTEPS==YA)
// code removed
#endif

cve->cgok=1; cgoknr=0; evtnr=0; // change event nr
// the limit cgoknr<=CGOKSZ is put here because some x could be discarded
// because ko
for(ci=0;((ci<edp->cgarsze)&&(evtnr<CGEVXX));ci++) {
   if(edp->cgare[ci].cgo.ms0==0) goto GTLXXX;
   //for(ci=0;((ci<edp->cgarsze)&&(cgoknr<CGOKSZ));ci++) {
   // Geometry
   // coordinates are relative ((vx,vy) is in (0,0)),
   // movement of pts makes a "z"
   dpla=&edp->cgare[ci].cgo.dpl[0];
   Setedges(&dpla[0],&dpla[1],&cve->dpl[0]);
   // compiles ellissoid parameters
   cve->hex=(float)(cve->dpl[7].x-cve->dpl[0].x)/2;
   cve->hey=(float)(cve->dpl[0].y-cve->dpl[7].y)/2;
   cve->hez=(float)(cve->dpl[7].z-cve->dpl[0].z)/2;

   //max,min
   max=(cve->hex >=cve->hey) ? cve->hex  : cve->hey;
   max=(max>=cve->hez) ? max : cve->hez;
   min=(cve->hex <=cve->hey) ? cve->hex  : cve->hey;
   min=(min<=cve->hez) ? min : cve->hez;
   coe=(min/(float)max);
   //printf("%f\n",coe);
   //if(coe<0.5) { printf("usti "); }

   // compiles rotation matrix
   for(ii=0;ii<9;ii++) cve->rt[ii]=
      (((float)edp->cgare[ci].cgo.dgd[ii]/63)-(float)0.5)*2;
   //cve->rt[0]=1; cve->rt[4]=1; cve->rt[8]=1;
   /*th=((float)edp->cgare[ci].cgo.dgd[0]/63)*2*(float)3.14159;
   ph=((float)edp->cgare[ci].cgo.dgd[1]/63)*2*(float)3.14159;
   ps=((float)edp->cgare[ci].cgo.dgd[2]/63)*2*(float)3.14159;
   cve->rt[0]=+cos(th)*cos(ps);
   cve->rt[1]=-cos(ph)*sin(ps) +sin(ph)*sin(th)*cos(ps);
   cve->rt[2]=+sin(ph)*sin(ps) +cos(ph)*sin(th)*cos(ps);
	cve->rt[3]=+cos(th)*sin(ps);
   cve->rt[4]=+cos(ph)*cos(ps) +sin(ph)*sin(th)*sin(ps);
   cve->rt[5]=-sin(ph)*cos(ps) +cos(ph)*sin(th)*sin(ps);
   cve->rt[6]=-sin(th);
   cve->rt[7]=+sin(ph)*cos(th);
   cve->rt[8]=+cos(ph)*cos(th);*/

   //cve->rt[0]=1; cve->rt[1]=0; cve->rt[2]=0; // no rot
   //cve->rt[3]=0; cve->rt[4]=1; cve->rt[5]=0; // no rot
   //cve->rt[6]=0; cve->rt[7]=0; cve->rt[8]=1; // no rot

   // calc for remred
   //ax=vx+(int)(cve->rt[0]*bx+cve->rt[1]*by+cve->rt[2]*bz);
   //ay=vy+(int)(cve->rt[3]*bx+cve->rt[4]*by+cve->rt[5]*bz);
   //az=vz+(int)(cve->rt[6]*bx+cve->rt[7]*by+cve->rt[8]*bz);

   //cve->cgok=1;
   matched=NO;
   // scans the grid
   for(ri=0;ri<DHARLS;ri++) {
      if(edp->drvaro[ri].x==-1) goto GPTEOB;
      memset(&curcl,0,sizeof(Clsr));
      //memcpy(&curcl,&edp->clar[vx][vy][vz],sizeof(Clsr));
      Lwriter(Lxxx,&curcl,ri,+1,edp->cndaro[ri],-1);
      vx=edp->drvaro[ri].x;
      vy=edp->drvaro[ri].y;
      vz=edp->drvaro[ri].z;
      #if(DEBUG0==YA)
      if(NDIMS==2)if(vz!=0) printf(" z error");
      #endif
      if((Lreader(Lcnd,&curcl)!=CLALIVE)||
         (Lreader(Ldrv,&curcl)!=1))     goto GPTEOB;
      if((cve->cgok!=1)||(evtnr>evtnr)) goto GPTEOB;
      //  ACHTUNG: with Matchet it can match more cells,with dhnrx JUST ONE!!
      res=Mocmatch(&edp->cgare[ci].mos[0],&edp->dhar[ri].moc[0],as);
      if(res!=YA) goto GPTEOB;
      //if(((Matchet(&edp->cgare[ci].mos[0],&moc[0],
      //  NAPMIN,FSCMAX,&sva,&svb)==NO)))
      // goto EOBCL;
      //if(edp->cgare[ci].dhnrx[zi]!=Lreader(Ldhn,&curcl)) goto GPTEOB;
      cve->clok=1; matched=YA;

      //$ Checks coordinates ------------------------------
      //$ Checks coordinates_end --------------------------

      //$ clok check --------------------------------------
      if(cve->clok==0) goto GPTEOB;
      // ex geometric calcul -----------------------------
      // New moc's are numbered consecutively following a 'z'

      // updates drvaro
      ivaro=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
      edp->drvaro[ivaro].x=-1;
      edp->cndaro[ivaro]=CLNOCL0;

      // Copies mother into mocl and deletes mother
      memcpy(&edp->moclp,&edp->clar[vx][vy][vz],sizeof(Clsr));
      #if(MNETON==YA) //mclvar is ptr!
      memcpy(&edp->momcl, edp->clar[vx][vy][vz].mclvar,sizeof(Mcl));
      #endif
      memcpy(&edp->clar[vx][vy][vz],&edp->cst,sizeof(Clsr));

      edp->motcoord.x = vx;
      edp->motcoord.y = vy;
      edp->motcoord.z = vz;
      //if(edp->cgare[ci].cgo.ms0==1) Remred(thid,cve,gi,ci,vx,vy,vz,0);
      Brush(thid,cve,gi,as,ci);
      Clset(thid,cve,gi,as,ci);
      evtnr++;
      //if(edp->cgare[ci].cgo.ms0==1) Remred(thid,cve,gi,ci,vx,vy,vz,1);
      GPTEOB:cvar=cvar;
   }
   //$ edp->cgare[ci] processing_end ---------------------------
   if((cve->cgok==1)&&(matched==YA)) {
      cgoknr++; }
   cvar=cvar;//anchor
   // Movie steps
   GTLXXX:cvar=cvar;
}

//Movie(thid,cve,gi,as,us);
#if(MNETON==YA)
// influences on cells after creation (metabol. only)
for(ci=0;(ci<edp->cgarszr);ci++) {
   if(edp->cgarr[ci].cgo.ms0==0) {
      FORVXYZ {
         if (edp->clar[vx][vy][vz].dhnrc2!=-1) {          // Achtung dhnrx[0]
            if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==0) // non driver!!!
            if(Lreader(Ldhn,&edp->clar[vx][vy][vz]) ==
               edp->cgarr[ci].dhnrx[0]) {
               for(mz=vz-1;mz<=vz+1;mz++)
               for(mx=vx-1;mx<=vx+1;mx++)
               for(my=vy-1;my<=vy+1;my++) {
                  if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==1) {
                     Dthrmnet(thid,cve,gi,ci,mx,my,mz,0,-1,-1,-1);
                  }
               }
            }
         }
      }
   }
}
#endif

edp->evtnr[as]=evtnr;
if(thid==0) if(gi==0) edp->evtnrf[as]=evtnr;
edp->popa[0]->guys[gi].evtnr[as] = evtnr;

#if(DEBUG0==YA)
if(cve->cgok!=1) {
   printf(" gi: %d dhnr: %d",gi,edp->dhnr);
   Leavexec(str); }
#endif

#if(ZSTEPS==YA)
// code removed
#endif

cvar=cvar;//anchor
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void  Body::Movie(int thid,Cvare *cve,int gi,int as,int us) {
#if(ZSTEPS==YA)
// code removed
#endif
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void  Body::Brush(int thid,Cvare *cve,int gi,int as,int ci) {
char  cvar=0;
int   bx,by,bz,dx,dy,dz,kc;
float hex,hey,hez,fvx,fvy,fvz;
Exbd  *edp=exbd[thid];
int vx = edp->motcoord.x;
int vy = edp->motcoord.y;
int vz = edp->motcoord.z;

// ellissoid: semi-axes, centre and displacement
kc = 2*DPLMAX/2;
hex = cve->hex;
hey = cve->hey; 
hez = cve->hez; 
dx = (int)cve->hex+cve->dpl[0].x;
dy = (int)cve->hey+cve->dpl[7].y;
dz = (int)cve->hez+cve->dpl[0].z;
// xxxx
fvx=1; //fvx=(1.00+(0.33*(float)edp->cgare[ci].cgo.dgd[7]/63));
fvy=1; //fvy=(1.00+(0.33*(float)edp->cgare[ci].cgo.dgd[7]/63));
fvz=1; //fvz=(1.00+(0.33*(float)edp->cgare[ci].cgo.dgd[7]/63));

// xxxx
for(bz=(kc-(int)hez-1);bz<=(kc+(int)hez+1);bz++)
for(by=(kc-(int)hey-1);by<=(kc+(int)hey+1);by++)
for(bx=(kc-(int)hex-1);bx<=(kc+(int)hex+1);bx++) {
   cve->buf0[bx][by][bz]=6; // no signal
   // ellissoid
   if((pow((bx-kc)/(hex*fvx),2)+
       pow((by-kc)/(hey*fvy),2)+
       pow((bz-kc)/(hez*fvz),2))<=1) {
      if((edp->cgare[ci].cgo.ms0==1)||(edp->cgare[ci].cgo.ms0==3))
         cve->buf0[bx][by][bz]=7; // normal signal
      if( edp->cgare[ci].cgo.ms0==2)
         cve->buf0[bx][by][bz]=8; // delete signal
      if((edp->cgare[ci].cgo.ms0==1)||(edp->cgare[ci].cgo.ms0==3))
      if((bx%NDQXXX==0)&&(by%NDQXXX==0)&&(bz%NDQXXX==0))
         cve->buf0[bx][by][bz]=9; // driver signal
      cvar=0;
   }
}

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Clset(int thid,Cvare *cve,int gi,int as,int ci) {
char  cvar=0;
int   ax,ay,az,bx,by,bz,kc;
int   dx,dy,dz,ix,iy,iz,at;
int   done,clcnd,bufval,dhnrnor;
int moc[LFSPAN],mocmother[LFSPAN];
float hex,hey,hez,qx,qy,qz,rt[9];
Exbd *edp=exbd[thid];
int vx = edp->motcoord.x;
int vy = edp->motcoord.y;
int vz = edp->motcoord.z;

at = Lreader(Ldhn,&edp->moclp);
Moccopy(&mocmother[0],&edp->dhar[at].moc[0]);
cve->smocnew=10; done=NO;
dhnrnor=edp->dhnr+1;
memcpy(&rt[0],&cve->rt[0],sizeof(float)*9);

// ellissoid: semi-axes, centre and displacement
kc = 2*DPLMAX/2;
hex = cve->hex;
hey = cve->hey; 
hez = cve->hez; 
dx = (int)cve->hex+cve->dpl[0].x;
dy = (int)cve->hey+cve->dpl[7].y;
dz = (int)cve->hez+cve->dpl[0].z;
// xxxx
for(ix=0;ix<2;ix++)
for(iy=0;iy<2;iy++)
for(iz=0;iz<2;iz++)
for(bz=(kc-(int)hez-1);bz<=(kc+(int)hez+1);bz++)
for(by=(kc-(int)hey-1);by<=(kc+(int)hey+1);by++)
for(bx=(kc-(int)hex-1);bx<=(kc+(int)hex+1);bx++) {
   bufval=cve->buf0[bx][by][bz];
   if(bufval!=6) {
      qx = rt[0]*(bx-kc)+rt[1]*(by-kc)+rt[2]*(bz-kc);
      qy = rt[3]*(bx-kc)+rt[4]*(by-kc)+rt[5]*(bz-kc);
      qz = rt[6]*(bx-kc)+rt[7]*(by-kc)+rt[8]*(bz-kc);
      if(ix==0) ax = vx+dx+(int)floor(qx);
      else      ax = vx+dx+(int)ceil (qx);
      if(iy==0) ay = vy+dy+(int)floor(qy);
      else      ay = vy+dy+(int)ceil (qy);
      if(iz==0) az = vz+dz+(int)floor(qz);
      else      az = vz+dz+(int)ceil (qz);
      if((ax<0)||(ax>=GRIDXX)) goto CLSEBLUE;
      if((ay<0)||(ay>=GRIDYY)) goto CLSEBLUE;
      if((az<0)||(az>=GRIDZZ)) goto CLSEBLUE;
      edp->tmpcoord.x = ax;
      edp->tmpcoord.y = ay;
      edp->tmpcoord.z = az;
      if((bufval==7)||(bufval==8)) {        //normal (7) or delete (8) signal
         if(bufval==7) { Moccopy(&moc[0],&mocmother[0]); clcnd=CLSLEEP; }
         if(bufval==8) { Moccopy(&moc[0],&edp->moct[0]); clcnd=CLNOCL0; }
         if(done==YA) goto GTLAAA;
         if(bufval==7) { cve->smocnew=+10; }                         // normal
         if(bufval==8) { cve->smocnew=-10; }                         // delete
         Dharupd(thid,cve,gi,&edp->cgare[ci],&moc[0],as,0,NO);
         done=YA;
         GTLAAA:cvar=cvar;
         Daughter(thid,cve,gi,ci,clcnd,NO,dhnrnor);
         Dthrmnet(thid,cve,gi,ci,clcnd,NO,dhnrnor);
      }
      if((ix==1)&&(iy==1)&&(iz==1)) // last cycle to avoid drv get cancelled
      if(bufval==9) {         // driver signal
         cve->smocnew++; clcnd=CLSLEEP; 
         Moccopy(&moc[0],&mocmother[0]);
         Dharupd(thid,cve,gi,&edp->cgare[ci],&moc[0],as,1,YA);
         Daughter(thid,cve,gi,ci,clcnd,YA,-1);
         Dthrmnet(thid,cve,gi,ci,clcnd,YA,-1);
      }
      CLSEBLUE:cvar=cvar;
   }
}

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Dharupd(int thid,Cvare *cve,int gi,Cgx *cgx,int moc[],
                   int asval,int clr,int drv) {
int  hi,mocnew[LFSPAN],smocmax;
Exbd *edp=exbd[thid];

Moccopy(&mocnew[0],&moc[0]); 
mocnew[asval]=cve->smocnew;
if(memcmp(&edp->dhar[edp->dhnr].moc[0],&mocnew[0],sizeof(int)*LFSPAN)) {
   if((edp->dhnr+1)<=(DHARLS-1)) {
      edp->dhnr++;
      memcpy(&edp->dhar[edp->dhnr].cgx,cgx,sizeof(Cgx));
      for(hi=0;hi<LFSPAN;hi++) 
         edp->dhar[edp->dhnr].moc[hi]=mocnew[hi];
      edp->dhar[edp->dhnr].asval=asval;
   }
   else cve->cgok=0;
}

if((clr==0)||(clr==1)) smocmax=SMOCMA;
else                   smocmax=SMOCMB;
if(cve->smocnew>=smocmax) { printf(" %d %d",clr,cve->smocnew); cve->cgok=0; }

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Daughter(int thid,Cvare *cve,int gi,int ci,
                    int clcnd,int drv,int dhnrnor) {
int  aiv,biv,civ,oiv,conr;
Exbd *edp=exbd[thid];
int ax = edp->tmpcoord.x;
int ay = edp->tmpcoord.y;
int az = edp->tmpcoord.z;

#if(DEBUG0==YA)
if(NDIMS==2)if(az!=0) printf(" z error");
#endif
#if(NDIMS==2)
az=0;
#endif

conr=edp->cgare[ci].cgo.conr;
aiv=Lreader(Lcol,&edp->clar[ax][ay][az]);    // previous colour
biv=Lreader(Ldrv,&edp->clar[ax][ay][az]);    // previous driver status
civ=Lreader(Lcnd,&edp->clar[ax][ay][az]);    // previous cnd
#if(DEBUG0==YA)
if(clcnd==CLNOCL0)if(civ==CLNOCEL) clcnd=CLNOCEL;
#endif

// updates drvaro 
if(biv==1) {
   oiv = Lreader(Ldhn,&edp->clar[ax][ay][az]);
   if(edp->drvaro[oiv].x==ax)
   if(edp->drvaro[oiv].y==ay)
   if(edp->drvaro[oiv].z==az) {
      edp->drvaro[oiv].x = -1;
      edp->cndaro[oiv] = CLNOCL0;
   }
}
// updates drvaro_end 

if(drv==0) Lwriter(Lxxx,&edp->clar[ax][ay][az],dhnrnor,0,clcnd,-1);
if(drv==1) Lwriter(Lxxx,&edp->clar[ax][ay][az],edp->dhnr,1,clcnd,-1);
if(ci!=-1) Lwriter(Lxxx,&edp->clar[ax][ay][az],-1,-1,-1,conr);
else       Lwriter(Lxxx,&edp->clar[ax][ay][az],-1,-1,-1,aiv);

// updates drvaro 
if(drv==1) if(clcnd==CLSLEEP) {
   oiv = edp->dhnr;
   edp->drvaro[oiv].x = ax;
   edp->drvaro[oiv].y = ay;
   edp->drvaro[oiv].z = az;
   edp->cndaro[oiv] = CLSLEEP;
}
// updates drvaro_end 

// updates bound box
if(ax < edp->bbl.x) edp->bbl.x = ax; 
if(ay < edp->bbl.y) edp->bbl.y = ay; 
if(az < edp->bbl.z) edp->bbl.z = az; 
if(ax > edp->bbu.x) edp->bbu.x = ax; 
if(ay > edp->bbu.y) edp->bbu.y = ay; 
if(az > edp->bbu.z) edp->bbu.z = az; 

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Dthrmnet(int thid,Cvare *cve,int gi,int ci,
                    int clcnd,int drv,int dhnrnor) {
#if(MNETON==YA)
char cvar;
int  *ivard,ii=0,si,ox;
int ax = edp->tmpcoord.x;
int ay = edp->tmpcoord.y;
int az = edp->tmpcoord.z;
Clsr *neucl;
Exbd *edp=exbd[thid];

if(drv==0) goto GTLJJJ;
neucl=&edp->clar[ax][ay][az];
neucl->mclvar=&edp->mxxxar[edp->dhnr];
// olrxxx
if(ci!=-1) neucl->mclvar->olrxxx=edp->cgare[ci].cgo.olrxxx;
else       neucl->mclvar->olrxxx=-1; // doping-generated drivers are excluded
// oxarap - inherits mother's        // from metabol.
for(ox=0;ox<OXARSZ;ox++) neucl->mclvar->oxarap[ox]=edp->momcl.oxarap[ox];
// oxarap - introduces changes
for(ii=0;ii<OXRCHD;ii++) if(ci!=-1) {
   if(edp->cgare[ci].cgo.oxrchd[ii]<OXARSZ) {
      ivard=&neucl->mclvar->oxarap[edp->cgare[ci].cgo.oxrchd[ii]];
      if(*ivard==0) *ivard=1;
      else          *ivard=0;
   }
}
// iosmsk
for(ii=0;ii<2;ii++) for(si=0;si<SZSUSP;si++)
   neucl->mclvar->iosmsk[ii][si]=
   (ci!=-1) ? edp->cgare[ci].cgo.iosmsk[ii][si] : -1;
GTLJJJ:cvar=cvar;
#endif

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Body::Calcageprof(int thid,int repstep) {
int ii,at; float ar,br;
float pbudget,pbudget0,tbudget;
Exbd *edp = exbd[thid];

// for fit calc (tcoefar) with repstep of edp
// for mutation (pmutar) with repstep of Guy

// calc pmutar for AGEING == 0
pbudget = 0;
for(ii=0;ii<LFSPAN;ii++) opened
   edp->pmutar[ii] = 0.5;
   edp->tcoefar[ii] = 0;
   pbudget += edp->pmutar[ii];
closed
edp->tcoefar[repstep] = 1.00;
pbudget0 = pbudget;

#if(AGEFIT == 1) 
// calc tcoefar
tbudget = 0;
for(ii=0;ii<repstep;ii++) 
   edp->tcoefar[ii] = 0;
for(ii=repstep;ii<LFSPAN;ii++) opened
   edp->tcoefar[ii] = 1-Bsigmoid(ii,0.5,repstep+0);
   tbudget += edp->tcoefar[ii];
closed
// the sum of tcoefar must be = 1
ar = tbudget;
tbudget = 0;
for(ii=0;ii<LFSPAN;ii++) opened 
   edp->tcoefar[ii] /= ar;
   tbudget += edp->tcoefar[ii];
closed
#endif

#if(AGEMUT == 1)
pbudget = 0;
at = repstep+GRACEP;
for(ii=0;ii<repstep;ii++) 
   edp->pmutar[ii] = Bsigmoid(ii,0.5,at);
for(ii=repstep;ii<LFSPAN;ii++) opened
   edp->pmutar[ii] = Bsigmoid(ii,0.5,at);
   pbudget += edp->pmutar[ii];
closed
// the sum of pmutar must be = for AGEING == 0 and == 1
/*ar = pbudget; pbudget = 0;
for(ii=0;ii<LFSPAN;ii++) opened
   edp->pmutar[ii] *= (pbudget0/ar);
   pbudget += edp->pmutar[ii];
closed*/
#endif

}
