
#include "danxincl.h"

// Global var
Exbd  *exbd[NCORES];
Cvare *cve_[NCORES];
long  buflen,buflen0,buflen1,buflen3;
char  *buffer;

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int  main(int argc, char *argv[], char *env[]) {
char cvar = 0;
int  opt,thid,pi,vx,vy,vz;
long int msa,msb,msc,msd,msf;
Body *bdp;
Exbd *edp;
#if(MYMPI==1)
int rc,size,si;
MPI_Status stat;
#endif

#if(DEBUG0==YA)
double a=3.0,b=7.0,c;
set_fpu (0x27F);  /* use double-precision rounding */
c=a/b;
if (c==a/b) printf ("comparison succeeds\n");
else        printf ("unexpected result\n");
#endif

#if(DEBUG0==YA)
int ii,ei,gl,gu; float bfv;
for(ii=1;ii<=20;ii++) {
   printf("\n");
   for(ei=0;ei<ii;ei++) {
      bfv=NNGUYS/(float)ii; 
      gu=(int)(bfv*(ei+1));
      if (ei==ii-1) gu=NNGUYS; 
      printf(" %3d",gu);
   }
}
#endif

#if(DEBUG0==YA)
printf("\nMemory check\n");
printf("sizeof clar       : %ld\n",(long int)sizeof(Clsr)*SZGRID);
printf("sizeof clarq      : %ld\n",(long int)sizeof(Clsr)*8*DPVMAX);
printf("sizeof cgar       : %ld\n",(long int)sizeof(Cgx)*CGARSZ);
printf("sizeof dhar       : %ld\n",(long int)sizeof(Cge)*NNGUYS);
printf("sizeof bstepsgrid : %ld\n",(long int)sizeof(Dpel)*SZGRID);
printf("sizeof Clsr       : %ld\n",(long int)sizeof(Clsr));
printf("sizeof Exbd       : %ld\n",(long int)sizeof(Exbd));
printf("sizeof Cgx        : %ld\n",(long int)sizeof(Cgx));
printf("sizeof Cge        : %ld\n",(long int)sizeof(Cge));
printf("sizeof rrorder    : %ld\n",(long int)sizeof(Coord)*SZGRID);
printf("sizeof rrorderdist: %ld\n",(long int)sizeof(float)*SZGRID);
printf("sizeof clarf      : %ld\n",(long int)sizeof(Clsr)*SZGRID);
printf("sizeof dharf      : %ld\n",(long int)sizeof(Cge)*DHARLS);
printf("sizeof drvar0     : %ld\n",(long int)sizeof(Coord)*LFSPAN*DHARLS);

msa=(sizeof(Exbd)*4)/1000000;
msb=(sizeof( int)*SZGRID*4)/1000000;
msc=(sizeof(Dpel)*SZGRID*LFSPAN)/1000000;
msd=(sizeof( Guy)*NNGUYS*4)/1000000;
msf=msa+msb+msc+msd;
printf("sizeof Exbd  (MB,4 core): %ld\n",msa);
printf("sizeof envr1 (MB,4 core): %ld\n",msb);
printf("sizeof envr2 (MB,4 core): %ld\n",msc);
printf("sizeof popa  (MB,4 core): %ld\n",msd);
printf("tot                     : %ld\n",msf);
#endif

// HINT UNIX
//srand(time(0));
//srand(RNSEED);
bdp =new Body();
if(argv[1]!=NULL) opt=0;
else              opt=1;

#if(MYMPI==1)
rc=MPI_Init(NULL,NULL);
if (rc!=MPI_SUCCESS)
 { printf ("Error MPI: Abort.\n"); MPI_Abort(MPI_COMM_WORLD, rc); }
else
 { printf ("\nMPI_Init ok\n"); }
MPI_Comm_size (MPI_COMM_WORLD,&size); printf ("size: %d\n",size);
#endif

// calc all -----------------------------------------------------------------
for(ei=0;ei<NCORES;ei++) {
   thid=Getthid(&edp);
   if (thid==ei)
    { exbd[ei] = (Exbd *)malloc(sizeof(Exbd ));
      cve_[ei] = (Cvare*)malloc(sizeof(Cvare));
      for(pi=0;pi<NPOPS;pi++) exbd[ei]->popa[pi]=new Pop(ei,bdp);
      bdp->Initlocv(ei);
      bdp->Bodinit(ei);
      bdp->Envinit(ei,0);
      exbd[ei]->fdone=0; }
   printf("\nThread %d ", thid);
}
// calc all_end -------------------------------------------------------------

// calc master --------------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   //Txt2vtk(thid,1,46); exit(0);
}
// calc master_end ----------------------------------------------------------

// calc master --------------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   if(opt==0) bdp->Loadmemo(0);
   if(opt==1) edp->cn0=0;
}
// calc master_end ----------------------------------------------------------

// calc master --------------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   remove(CONSFN); 
   remove(CONSFT); 
   remove(CONSFA);
   if(ISGRID==1) opened
      bdp->Loadgrid(0,(char *)CETISFN,0); 
      bdp->Loadgrid(0,(char *)CDISFN,1);
   closed
   bdp->Loadgrid(0,(char *)CDTGFN,2);
   bdp->Loadgrid(0,(char *)MNTGFN,3);
}
// calc master_end ----------------------------------------------------------

// calc buflen
// sendrec_0
buflen0 =sizeof(int);
buflen0+=sizeof(int)*SZGRID; 
if(ISGRID==1) buflen0*=3;
buflen0+=sizeof(Mtv);
// sendrec_1
buflen1 =sizeof(int)*7;
buflen1+=sizeof(Guy);
//buflen1+=sizeof(int)*NNGUYS; // rndmpt
buflen1+=sizeof_gen_*(NNGUYS/NCORES+1);
// sendrec_3
buflen3 =sizeof(int);
buflen3+=sizeof(int);
buflen3+=sizeof(float)*(NNGUYS/NCORES+1);
buflen3+=sizeof(float)*(NNGUYS/NCORES+1);
buflen3+=sizeof(float)*(NNGUYS/NCORES+1)*FITHST*LFSPAN;
buflen3+=sizeof(Cge)*(NNGUYS/NCORES+1)*DHARLS;
buflen3+=sizeof(int)*(NNGUYS/NCORES+1);
// calc
buflen=(buflen1>=buflen0) ? buflen1 :buflen0;
buflen=(buflen3>=buflen ) ? buflen3 :buflen ;
printf("%ld %ld %ld %ld",buflen0,buflen1,buflen3,buflen);
buffer=(char*)malloc(buflen);

// send-receive 
#if(MYMPI==0)
// cn0,envr
for(ei=1;ei<NCORES;ei++) {
   exbd[ei]->cn0=exbd[0]->cn0;
   FORVXYZ {
      exbd[ei]->envr.cdtgooodplgrid[vx][vy][vz]
      =exbd[0]->envr.cdtgooodplgrid[vx][vy][vz];
      if(ISGRID!=1) goto GTL000;
      exbd[ei]->envr.etisooodp0grid[vx][vy][vz]
      =exbd[0]->envr.etisooodp0grid[vx][vy][vz];
      exbd[ei]->envr.cdisooodp0grid[vx][vy][vz]
      =exbd[0]->envr.cdisooodp0grid[vx][vy][vz];
      GTL000: cvar=cvar;
      memcpy(&exbd[ei]->envr.mtv,&exbd[0]->envr.mtv,sizeof(Mtv));
   }
}
#endif
#if(MYMPI==1) // sendrec_0
if (thid==0) {
   si=0;
   Mpscpy(&buffer[si],&edp->cn0,sizeof(int),&si);
   FORVXYZ Mpscpy(&buffer[si],&edp->envr.cdtgooodplgrid[vx][vy][vz],
      sizeof(int),&si); if(ISGRID!=1) goto GTL001;
   FORVXYZ Mpscpy(&buffer[si],&edp->envr.etisooodp0grid[vx][vy][vz],
      sizeof(int),&si);
   FORVXYZ Mpscpy(&buffer[si],&edp->envr.cdisooodp0grid[vx][vy][vz],
      sizeof(int),&si);
   GTL001: cvar=cvar;
   //memcpy(buffer[si++],&edp->envr.mtv,sizeof(Mtv));
   for(ei=1;ei<NCORES;ei++)
      rc=MPI_Send(buffer,buflen0,MPI_BYTE,ei,0,MPI_COMM_WORLD);
}
else /*FORVXYZ*/ {
   rc=MPI_Recv(buffer,buflen0,MPI_BYTE, 0,0,MPI_COMM_WORLD,&stat);
   si=0;
   Mprcpy(&edp->cn0,&buffer[si],sizeof(int),&si);
   FORVXYZ Mprcpy(&edp->envr.cdtgooodplgrid[vx][vy][vz],&buffer[si],
      sizeof(int),&si); if(ISGRID!=1) goto GTL002;
   FORVXYZ Mprcpy(&edp->envr.etisooodp0grid[vx][vy][vz],&buffer[si],
      sizeof(int),&si);
   FORVXYZ Mprcpy(&edp->envr.cdisooodp0grid[vx][vy][vz],&buffer[si],
      sizeof(int),&si);
   GTL002: cvar=cvar;
   //memcpy(&edp->envr.mtv,buffer[si++],sizeof(Mtv));
}
#endif
// send-receive_end 

edp->t0=(long)time(0);
thid=Getthid(&edp);
for(edp->cn=edp->cn0;edp->cn<=CYCLES;edp->cn++) {
   bdp->Baseloop(opt,bdp);
}

#if(MYMPI==1)
MPI_Finalize();
#endif
return 0;

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void  Body::Baseloop(int opt,Body *bdp) {
char  cvar=0,*atmpstr,*atmpstr1;
int   thid,gi,pi,gy;
int   gl,gu,ei,ii,aiv,biv;
float gph,af,bfv,ar,br,*arp;
FILE  *fptr00=NULL; // to avoid warning
Exbd  *edp;
Guy   *gyp,*gzp;
#if(MYMPI==1)
int size,rc,si,hi;
MPI_Status stat;
#endif

atmpstr  =(char *)malloc(200);
atmpstr1 =(char *)malloc(200);
thid = Getthid(&edp); // gets thread id

// calc master 
thid=Getthid(&edp);
if (thid==0) {
   fptr00=fopen(CONSFN, "w");
   edp->ausdr=0; if((edp->cn%SHOWSTEP)==0) edp->ausdr=1;
   strcpy(atmpstr,"\n%d) ");
   if(edp->ausdr==1) {
      fprintf(stdout,atmpstr,edp->cn);
      fprintf(fptr00,atmpstr,edp->cn);
   } else fprintf(stdout,"X");
   edp->pnr=1;
}
// calc master_end 

GSLAVE:cvar=cvar; // slave starts here
#if(MYMPI==1)
thid=Getthid(&edp);
if (thid!=0) edp->cn++;
#endif

// calc all
for(ei=0;ei<NCORES;ei++) {
   thid=Getthid(&edp);
   if (thid==ei) {
      // gq
      if((0<=edp->cn)&&(edp->cn<edp->frz[0].ge)) edp->gq=0;
      for(ii=0;ii<NAMS-1;ii++)
         if((edp->frz[ii].ge<=edp->cn)&&(edp->cn<edp->frz[ii+1].ge))
          { edp->gq=ii+1; break; }
      // cgar limits
      edp->cgarxf=edp->frz[edp->gq].xf;
      edp->cgarsz=edp->frz[edp->gq].xe;
      for(pi=0;pi<NPOPS;pi++) {
         edp->popa[pi]->dnaxf=(GNHSZ+OXARSQ+(CGOXSQ*edp->cgarxf));
         edp->popa[pi]->dnasz=(GNHSZ+OXARSQ+(CGOXSQ*edp->cgarsz));
      }
   }
}
// calc all_end

// calc master 
thid=Getthid(&edp);
if (thid==0) {
   //Prexline(0);
   memcpy(&edp->guyf,&edp->popa[0]->guys[0],sizeof(Guy));
   strcpy(atmpstr," [gq: %d ge: %5d xf: %3d xe: %3d ls: %d up: %d]");
   if(edp->ausdr==1) {
      Printf4(fptr00,atmpstr,edp->gq,
         edp->frz[edp->gq].ge,edp->frz[edp->gq].xf,
         edp->frz[edp->gq].xe,edp->frz[edp->gq].ls,
         edp->frz[edp->gq].us);
   }
}
// calc master_End

// sendrec_1 -------------------------------------------------------------
thid=Getthid(&edp);
//aiv=0;
aiv=edp->popa[0]->dnaxf;
biv=edp->popa[0]->dnasz;
buflen1 =sizeof(int)*7;
buflen1+=sizeof(Guy);
//buflen1+=sizeof(int)*NNGUYS; // rndmpt
buflen1+=sizeof(int)*(NNGUYS/NCORES+1)*(biv-aiv);
if (edp->ausdr==1) printf(" buflen1=%ld",buflen1);
#if(MYMPI==0)
for(ei=1;ei<NCORES;ei++) {
   exbd[ei]->cn=exbd[0]->cn;
   exbd[ei]->gq=exbd[0]->gq;
   exbd[ei]->xq=exbd[0]->xq;
   exbd[ei]->cgarxf=exbd[0]->cgarxf;
   exbd[ei]->cgarsz=exbd[0]->cgarsz;
   memcpy(&exbd[ei]->guyf,&exbd[0]->guyf,sizeof(Guy));
   for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<POPXSZ;gy++) {
      gyp=&exbd[ei]->popa[pi]->guys[gy];
      gzp=&exbd[ 0]->popa[pi]->guys[gy];
      memcpy(&gyp->gen[aiv],&gzp->gen[aiv],sizeof(int)*(biv-aiv));
   }
}
#endif
#if(MYMPI==1)
if (thid==0) {
   for(ei=1;ei<NCORES;ei++) {
      bfv=NNGUYS/(float)NCORES;
      gl=(int)(bfv*ei); gu=(int)(bfv*(ei+1));
      if (ei==NCORES-1) gu=NNGUYS;
      si=0;
      Mpscpy(&buffer[si],&edp->cn,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->gq,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->xq,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->cgarxf,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->cgarsz,sizeof(int),&si);
      Mpscpy(&buffer[si],&gl,sizeof(int),&si); //boundaries
      Mpscpy(&buffer[si],&gu,sizeof(int),&si); //boundaries
      Mpscpy(&buffer[si],&edp->guyf,sizeof(Guy),&si);
      for(gi=gl;gi<gu;gi++) {
         pi=gi/POPXSZ; gy=gi%POPXSZ;
         gyp=&edp->popa[pi]->guys[gy];
         Mpscpy(&buffer[si],&gyp->gen[aiv],sizeof(int)*(biv-aiv),&si);
      }
      rc=MPI_Send(buffer,buflen1,MPI_BYTE,ei,1,MPI_COMM_WORLD);
   }
}
else {
   if (0==0) { // to keep aligned
      si=0;
      rc=MPI_Recv(buffer,buflen1,MPI_BYTE,0,1,MPI_COMM_WORLD,&stat);
      Mprcpy(&edp->cn,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->gq,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->xq,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->cgarxf,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->cgarsz,&buffer[si],sizeof(int),&si);
      Mprcpy(&gl,&buffer[si],sizeof(int),&si); //boundaries
      Mprcpy(&gu,&buffer[si],sizeof(int),&si); //boundaries
      Mprcpy(&edp->guyf,&buffer[si],sizeof(Guy),&si);
      for(gi=gl;gi<gu;gi++) {
         pi=gi/POPXSZ; gy=gi%POPXSZ;
         gyp=&edp->popa[pi]->guys[gy];
         Mprcpy(&gyp->gen[aiv],&buffer[si],sizeof(int)*(biv-aiv),&si);
      }
   }
}
#endif
// send-receive_end ------------------------------------------------------

// calc all 
for(ei=0;ei<NCORES;ei++) {
   thid=Getthid(&edp);
   if (thid==ei) {
      Envinit(ei,1); // Inits env (actual grids only)
      edp->fset=0;
   }
}
// calc all_end 

// computes extremes
gl=0; gu=NNGUYS;
#if(MYMPI==1)
thid=Getthid(&edp);
bfv=NNGUYS/(float)NCORES;
gl=(int)(bfv*thid); gu=(int)(bfv*(thid+1));
if (thid==NCORES-1) gu=NNGUYS;
#endif

if (0==0) {
gl=0; gu=NNGUYS;
thid=Getthid(&edp);
bfv=NNGUYS/(float)NCORES;
gl=(int)(bfv*thid); gu=(int)(bfv*(thid+1));
if (thid==NCORES-1) gu=NNGUYS;
if (thid==0) edp->sr=0;
edp->ff=0;
for(gi=gl;gi<gu;gi++) {
   Devoloop(&gi,gu);
}
}

// calc master -------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   FILE *fp = fptr00;
   if(edp->ausdr==1) {
      //edp->repstep0 = 8;
      Printf4(fp,"\n\nrepstep: ");
      for(ii=0;ii<edp->frz[edp->gq].fs;ii++) Printf4(fp," ___");
      Printf4(fp," %3d",edp->frz[edp->gq].fs);      
      Printf4(fp,"\ndvsteps: ");
      for(ii=0;ii<LFSPAN;ii++) Printf4(fp," %3d",ii); 
      // xxxxxxxx
      Printf4(fp,"\ntcoefar: ");
      af = 0;
      for(ii=0;ii<LFSPAN;ii++) opened
         Printf4(fp," %3d",(int)(edp->tcoefar[ii]*100));
         af += edp->tcoefar[ii];
      closed
      Printf4(fp," tot: %2.1f",af);
      // xxxxxxxx
      Printf4(fp,"\n pmutar: ");
      af = 0;
      for(ii=0;ii<LFSPAN;ii++) opened
         Printf4(fp," %3d",(int)(edp->pmutar[ii]*100)); 
         af += edp->pmutar[ii]; 
      closed
      Printf4(fp," tot: %2.1f",af);
      // xxxxxxxx
      Printf4(fp,"\n events: ");
      aiv = 0; br = 0;
      bfv=NNGUYS/(float)NCORES;
      gl=0; gu=(int)bfv;
      for(ii=0;ii<LFSPAN;ii++) opened
         ar = 0;
         // statistic on first gu guys
         for(gi=gl;gi<gu;gi++)
            ar += edp->popa[0]->guys[gi].evtnr[ii];
         Printf4(fp," %2.1f",ar/gu);
         br += ar/gu; 
         //Printf4(fp," %3d",edp->evtnrf[ii]);
         //aiv += edp->evtnrf[ii]; 
      closed
      Printf4(fp," tot: %2.1f\n",br);
   }
}
// calc master_end -------------------------------------------------------

// send-receive 
thid=Getthid(&edp);
bfv=NNGUYS/(float)NCORES;
#if(MYMPI==0)
// consolidates pop
for(ei=1;ei<NCORES;ei++) {
   gl=(int)(bfv*ei); gu=(int)(bfv*(ei+1));
   if (ei==NCORES-1) gu=NNGUYS;
   for(gi=gl;gi<gu;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      exbd[ 0]->popa[pi]->guys[gy].shad=
      exbd[ei]->popa[pi]->guys[gy].shad;
      exbd[ 0]->popa[pi]->guys[gy].mfit=
      exbd[ei]->popa[pi]->guys[gy].mfit;
      memcpy(&exbd[0]->dharal[gi][0],&exbd[ei]->dharal[gi][0],
         sizeof(Cge)*DHARLS);
      exbd[0]->dhnral[gi]=exbd[ei]->dhnral[gi];
   }
}
#endif
#if(MYMPI==1) // sendrec_3
gl=(int)(bfv*thid); gu=(int)(bfv*(thid+1));
if (thid==NCORES-1) gu=NNGUYS;
//aiv=(sizeof(int)*(gu-gl)*DHARLS*LFSPAN);
//biv=(sizeof(int)*(gu-gl));
if (thid!=0) {
   si=0;
   Mpscpy(&buffer[si],&gl,sizeof(int),&si); // boundaries
   Mpscpy(&buffer[si],&gu,sizeof(int),&si); // boundaries
   for(gi=gl;gi<gu;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      gyp=&edp->popa[pi]->guys[gy];
      Mpscpy(&buffer[si],&gyp->shad,sizeof(float),&si);
      Mpscpy(&buffer[si],&gyp->mfit,sizeof(float),&si);
      for(ii=0;ii<FITHST;ii++) opened
         for(hi=0;hi<LFSPAN;hi++) opened
            ar = edp->shadhst[gi][ii][hi];
            Mpscpy(&buffer[si],&ar,sizeof(float),&si);
         closed
      closed      
      Mpscpy(&buffer[si],&edp->dharal[gi][0],sizeof(Cge)*DHARLS,&si);
      Mpscpy(&buffer[si],&edp->dhnral[gi],sizeof(int),&si);
   }
   rc=MPI_Send(buffer,buflen3,MPI_BYTE,0,3,MPI_COMM_WORLD);
}
else for(ei=1;ei<NCORES;ei++) { // ACHTUNG: deve ricevere da qlq processo!
   si=0;
   rc=MPI_Recv(buffer,buflen3,MPI_BYTE,MPI_ANY_SOURCE,3,
      MPI_COMM_WORLD,&stat);
   Mprcpy(&gl,&buffer[si],sizeof(int),&si); // boundaries
   Mprcpy(&gu,&buffer[si],sizeof(int),&si); // boundaries
   for(gi=gl;gi<gu;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      gyp=&edp->popa[pi]->guys[gy];
      Mprcpy(&gyp->shad,&buffer[si],sizeof(float),&si);
      Mprcpy(&gyp->mfit,&buffer[si],sizeof(float),&si);
      for(ii=0;ii<FITHST;ii++) opened
         for(hi=0;hi<LFSPAN;hi++) opened
            arp = &edp->shadhst[gi][ii][hi];
            Mprcpy(arp,&buffer[si],sizeof(float),&si);
         closed
      closed      
      Mprcpy(&edp->dharal[gi][0],&buffer[si],sizeof(Cge)*DHARLS,&si);
      Mprcpy(&edp->dhnral[gi],&buffer[si],sizeof(int),&si);
   }
   cvar=cvar;
}
#endif
// send-receive_end 

#if(MYMPI==1)
thid=Getthid(&edp);
if((thid!=0)&&((edp->cn)<CYCLES)) goto GSLAVE;
#endif

// calc master -----------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   Calcfit(0);
   Prexline(0);
   if(edp->ausdr==YA) { Showres (0,fptr00,atmpstr); Savememo (0); }
   if(edp->cn%GPSTEP==0) Germline(0); //Leavexec("testing Germliner");
   //if(ausdr==YA) { Showres (); Savememo (); }
   for(pi=0;pi<NPOPS;pi++) edp->popa[pi]->Galoop(0,0);      
   edp->t1 = (long)time(0); 
   gph = (double)((edp->cn-edp->cn0+1)*3600)/(edp->t1-edp->t0);
   sprintf(atmpstr,"gensperday: %.0f \n",gph*24);
   if(edp->ausdr==YA) opened
      fprintf(stdout,atmpstr,gph);
      fprintf(fptr00,atmpstr,gph);
   closed
   fclose(fptr00);
   COPYFILE; // macro good for two compilers
   if(edp->ausdr==YA) FileMerger();
   remove(CONSFT); 
   //if(edp->cn == 1) exit(0);
}
// calc master_end -------------------------------------------------------

free(atmpstr);
free(atmpstr1);

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void  Body::Devoloop(int *gip,int gu) {
int   thid,gi,pi,gy,as,ls,us;
int   ri,ce,vx,vy,vz,hi,an;
float shad,mfit;
Exbd  *edp;
Cvare *cve;

//printf("\n%d",gi);
gi = *gip;
//printf("\n%d",gi);
pi=gi/POPXSZ; gy=gi%POPXSZ;
//while((gi!=0)&&(fset!=1)) { cvar=cvar; }
thid=Getthid(&edp);
cve=cve_[thid];
edp->fset=0;
#if(DEBUG0==YA)
if(thid==0)
   if(edp->ausdr==1) if(gy==0) 
      printf("\nThread %d pi %d",thid,pi);
#endif
// Inits clar & dhar
FORVXYZ Clsrinit(&edp->clar[vx][vy][vz],CLNOCEL);
for(ce=0;ce<DHARLS;ce++) 
   memcpy(&edp->dhar[ce],&edp->cget,sizeof(Cge));
// Inits zygotes and isgrid
Gridinit(thid,gi);
// Decodes gen
if(edp->ff==0)
   edp->popa[pi]->Gendecoder(thid,edp->guyf.gen,NULL,0);
edp->popa[pi]->Gendecoder(thid,edp->popa[pi]->guys[gy].gen,NULL,1);
// mfit
edp->popa[pi]->guys[gy].shad=0;
edp->popa[pi]->guys[gy].mfit=0;
Calcageprof(thid, edp->frz[edp->gq].fs);
// DEVELOPMENT CYCLE
ls=0; us=LFSPAN-1;
if(edp->fdone!=0) { 
   ls=edp->frz[edp->gq].ls; 
   us=edp->frz[edp->gq].us; 
}
for(as=ls;as<=us;as++) {
   if ((edp->fdone==0)&&(as==edp->frz[edp->gq].ls)) {
      FORVXYZ memcpy(&edp->clarb[vx][vy][vz],
         &edp->clar[vx][vy][vz],sizeof(Clsr));
      memcpy(&edp->dharb[0],&edp->dhar[0],sizeof(Cge)*DHARLS);
      edp->dhnrb = edp->dhnr;
      edp->fset=1;
   }
   if ((edp->fdone!=0)&&(as==ls)) {
      FORVXYZ memcpy(&edp->clar[vx][vy][vz],
         &edp->clarb[vx][vy][vz],sizeof(Clsr));
      memcpy(&edp->dhar[0],&edp->dharb[0],sizeof(Cge)*DHARLS);
      edp->dhnr = edp->dhnrb;
   }
   Cgarprep(thid,cve,gi,as,ls);
   Shaper  (thid,cve,gi,as,us);
   if(as <= edp->frz[edp->gq].fs+GRACEP)
      Doper2(thid,cve,gi,as);
   // Fitness evaluation
   pi=gi/POPXSZ; gy=gi%POPXSZ;
   an = (edp->cn)/HSTSTP;
   if(1 == 1) { // always calculated
   //if(as >= edp->frz[edp->gq].fs) {
   //if(edp->tcoefar[as] != 0) {
      shad = Fitboxy(thid,gi);
      edp->popa[pi]->guys[gy].shad += 
         edp->tcoefar[as]*shad; 
      // History
      if(an<FITHST) edp->shadhst[gi][an][as] = shad;
      // Metabolic fitness evaluation
      #if(MNETON == YA)
      edp->fmfit = Mnetcalc(thid,gi);
      edp->popa[pi]->guys[gy].mfit +=  
         edp->tcoefar[as]*mfit; 
      #endif
   }   
   Gridupd(thid,gi,as,us);
}
// Copies first elements
if (edp->ff==0) {
   for(ce=0;ce<edp->cgarsz;ce++)
      memcpy(&edp->cgarf[ce],&edp->cgar[ce],sizeof(Cgx));
   memcpy(&edp->dharf,&edp->dhar,sizeof(Cge)*DHARLS);
   for(ce=0;ce<DHARLS;ce++) for(hi=0;hi<LFSPAN;hi++)
      edp->mocdvf[ce][hi] = edp->dhar[ce].moc[hi];
   edp->dhnrf = edp->dhnr;
   for(ri=0;ri<DHARLS;ri++)
      memcpy(&edp->drvarf[ri],&edp->drvaro[ri],sizeof(Coord));
   #if(DEBUG0==YA)
   FORVXYZ memcpy(&edp->clar0[vx][vy][vz],
      &edp->clar[vx][vy][vz],sizeof(Clsr));
   #endif
}
// MOCDEV update
memcpy(&edp->dharal[gi][0],&edp->dhar[0],sizeof(Cge)*DHARLS);
for(ce=0;ce<DHARLS;ce++)
   if((ce<=edp->dhnr)&&
      (edp->dhar[ce].asval<=edp->frz[edp->gq].fs))
      edp->dhnral[gi]=ce;
/*edp->dhnral[gi]=edp->dhnr;*/
// MOCDEV update_End
if (edp->ff==0) *gip--;
if((edp->ff==0)&&(edp->fset==1)) { edp->fdone=1; }
edp->ff++;

if (*gip==gu-1)
if((edp->cn<edp->frz[edp->gq].ge)&&
   ((edp->cn+1)>=edp->frz[edp->gq].ge))
   edp->fdone=0;

}

